<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html><html lang="zh-cn" class="do-cke"><head><meta charset="UTF-8"><meta name="renderer" content="webkit"><meta name="viewport" content="width=device-width,initial-scale=1, minimum-scale=1.0, maximum-scale=1, user-scalable=no, minimal-ui"><meta name="applicable-device" content="pc,mobile"><meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1"><!--[if lt IE 9]><meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE"><![endif]--><title>联系我们-四川凯聚鑫建设工程有限公司</title><meta name="robots" content="all"><meta name="keywords" content="成都梦之易"><style>.wow {visibility: hidden;}</style><!--[if lt IE 9]><style>.wow {visibility: visible;}</style><![endif]--><link href="/static/css/css.css" rel="stylesheet" type="text/css"><link href="/static/css/css1.css" rel="stylesheet" type="text/css"><link href="/static/css/style.css" rel="stylesheet" type="text/css"><style>
 
 body { background-attachment:scroll; }
 
 
 
 
 
 
 
 .do-site-name *,.do-nav-m-ul li a,.do-nav-m-ul .icon-isSub:before { color:rgb(18, 16, 16); }#do-m-menustate:checked ~ .do-nav-m .do-nav-m-title,#do-m-menustate ~ .do-nav-m .do-nav-m-title { background-color:rgb(255, 255, 255)!important; }.do-nav-m-ul > li > a,.do-nav-m-ul > li > ul { border-bottom-color:rgb(51, 51, 51); }.do-nav-m-bar { background-color:rgb(255, 255, 255)!important; }.do-nav-m .do-nav-page-name { color:rgb(30, 26, 26); }.do-m-menu-btn span { background-color:rgb(30, 26, 26)!important; }.do-nav-m-ul li a { font-size:14px; }.do-nav-m .do-site-name img { height:30px; }
 
 
 

 
 
 
 
 .lt-640 .do-online-service .do-online-service-btn,
 .lt-640 .do-kf-phoneDefault .do-online-service .do-box-title,
 .lt-640 .do-kf-phoneBottom .do-online-service .do-box-con,
 .lt-640 .do-kf-phoneRight .do-online-service .do-box-item
 { background-color:rgb(0, 119, 196)!important; }
 .lt-640 .do-kf-icon-box .do-box-item i,
 .lt-640 .do-kf-icon-box .do-box-item em
 { color:rgb(255, 255, 255); }
 
 
 

 
 

 
 
.col-autoHeight{display: table;width: 100%}
.col-autoHeight > [class*=do-col-]{display: table-cell;height: 100%;float: none;}
.col-autoHeight > [class*=do-col-] > .do-panelcol{position: initial;}
/*子导航*/

/*.z-sub-nav li a span:before{
 content: "";
 position: absolute;
 top: 8px;
 left: 0;
 height: 20px;
 width: 1px;
 background:rgb(203,203,203);
 transition:all ease-out .3s;
 
}

.z-sub-nav li:first-child a span:before{
 opacity: 0;
}


.z-subnav-conter span{padding:10px 20px; transition: all 0.3s;font-size: 14px;color:#888;}
.z-subnav-conter span:hover{color:rgb(186, 29, 29);}*/

 /* .z-subnav-conter span:hover{background-color: #ff0000;color:white;}
 .z-subnav-conter li.active span{background-color: #ff0000;color:white;}*/
 
 
 /*新闻内页*/
 .do-article-title{text-align: center;}
 .inline{border-bottom: 2px solid #eee;padding-bottom: 10px;}
 .do-article-title h1{font-size: 30px;}
 .z-subnav-conter li ul{border:none;} 
 .breadcrumb{display:none;}
 .qrcode-box{display: none;}
 .do-article{border:0;padding-right: 0;}
 .do-body-content .do-col-10{width:100% !important;}
 
 @media only screen and (max-width: 640px)
{
 .z-subnav-conter span{padding:0;}
 
 .z-subnav.do-level .z-sub-nav > li a{padding:0 10px;}
}



/*子导航*/
.z-sub-nav li a span:before{
 content: "";
 position: absolute;
 top: 8px;
 left: 0;
 height: 20px;
 width: 1px;
 background:rgb(203,203,203);
 transition:all ease-out .3s;
 
}

.z-sub-nav li:first-child a span:before{
 opacity: 0;
}


.z-subnav-conter span{
 padding:10px 20px; 
 transition: all 0.3s;
 /*font-size: 14px;*/
 color:#555;
}
.z-subnav-conter span:hover{background-color: rgb(186, 29, 29);color:white;}
.z-subnav-conter li.active span{background-color: rgb(186, 29, 29);color:white;}
 
 
 
 
@media only screen and (max-width: 640px){
 .z-subnav-conter span{padding: 10px 19px;}
 
 .z-sub-nav li a span:before{background:none;}
}
 
 
 /*nav*/

.do-header .z-nav-container li > ul:not(:empty ) {
 width: 317px;
 opacity: 0;
 left: -90px;
 transform: scale(0.8);
 -webkit-box-shadow: 0 8px 20px 0 rgba(0, 0, 0, .15);
 box-shadow: 0 8px 20px 0 rgba(0, 0, 0, .15);
 transition: all 1s;
 max-height: 0;
 -webkit-transition-timing-function: cubic-bezier(.075, .82, .165, 1);
 transition-timing-function: cubic-bezier(.075, .82, .165, 1);
 overflow: hidden;
 }
 

.do-header .z-nav-container li:hover > ul {
 opacity: 1;
 max-height: 100vh;
 padding: 50px 0;
 /*top: 57px;*/
 /*width:100%!important;*/
 -webkit-transform: scale(1);
 transform: scale(1);
 /*-webkit-transition-duration: .1s;*/
 /*transition-duration: .1s;*/
 /*-webkit-transition-timing-function: cubic-bezier(.075, .82, .165, 1);*/
 /*transition-timing-function: cubic-bezier(.075, .82, .165, 1);*/
 }

.do-header .z-nav-container li ul li {
 height: 36px !important;
 line-height: 36px !important;
 text-align: center;
 }
 
 
 .breadcrumb{padding:0 40px!important;}
 

 

 </style><script type="text/javascript">
 var StaticUrl = '//v1-ab.cdn-static.cn/';
 var sUserAgent= navigator.userAgent.toLowerCase();
 var bIsIpad= sUserAgent.match(/ipad/i) == "ipad";
 var bIsIphoneOs= sUserAgent.match(/iphone os/i) == "iphone os";
 var bIsMidp= sUserAgent.match(/midp/i) == "midp";
 var bIsUc7= sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
 var bIsUc= sUserAgent.match(/ucweb/i) == "ucweb";
 var bIsAndroid= sUserAgent.match(/android/i) == "android";
 var bIsCE= sUserAgent.match(/windows ce/i) == "windows ce";
 var bIsWM= sUserAgent.match(/windows mobile/i) == "windows mobile";
 
 var browser=navigator.appName;
 var b_version=navigator.appVersion;
 var version=b_version.split(";");
 var _vm = {};
 var trim_Version= version[1] ? version[1].replace(/[ ]/g,"") : "";
 var isIe = {
 ie6:browser=="Microsoft Internet Explorer" && trim_Version=="MSIE6.0",
 ie7:browser=="Microsoft Internet Explorer" && trim_Version=="MSIE7.0",
 ie8:browser=="Microsoft Internet Explorer" && trim_Version=="MSIE8.0",
 ie9:browser=="Microsoft Internet Explorer" && trim_Version=="MSIE9.0"
 }

 function isWeiXin(){
 var ua = window.navigator.userAgent.toLowerCase();
 if(ua.match(/MicroMessenger/i) == 'micromessenger'){
 return true;
 }else{
 return false;
 }
 }
 
 var version = {'css':'202031911342','js' :'2021519103916'};
 
 
 function setCookie(c_name,value,expiredays)
 {
 var exdate=new Date()
 exdate.setDate(exdate.getDate()+expiredays)
 document.cookie=c_name+ "=" +escape(value)+";path=/"+((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
 }

 
 setCookie("time_offset", -new Date().getTimezoneOffset()/60);
</script><script src="/static/js/jquery.min.js"></script><meta name="baidu-site-verification" content="code-g1dkSGOOQ0"><script>
var _hmt = _hmt || [];
(function() {
 var hm = document.createElement("script");
 hm.src = "https://hm.baidu.com/hm.js?4b0fff422353306d2f96d551796b0178";
 var s = document.getElementsByTagName("script")[0]; 
 s.parentNode.insertBefore(hm, s);
})();
</script><link rel="shortcut icon" type="image/ico" href=""><link rel="stylesheet" href="/static/css/style1.css"><style>
 
 
 
 
 
 #area_931935_0 > .do-area-bg .bgcolor,#area_931935_0 .fp-tableCell > .do-area-bg .bgcolor { background-color:rgba(249, 249, 249, 0.71); }.lt-ie9 #area_931935_0 > .do-area-bg .bgcolor,#area_931935_0 .fp-tableCell > .do-area-bg .bgcolor { filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#B2f9f9f9,endColorstr=#B2f9f9f9) }#area_931935_1 .do-area-bg-conter { }#area_931935_1 .do-row-one,#area_931935_1 .do-element-text { }#area_931935_1 .do-area-bg-conter:before { }
 
 #footer_931935_0 > .do-area-bg .bgcolor,#footer_931935_0 .fp-tableCell > .do-area-bg .bgcolor { background-color:rgb(0, 119, 196); }
 </style><script>
 (function(){
 var obj = (document.getElementsByTagName('head')[0]||body),
 js = null;
 if(location.search=="?debug=true"){
 js = document.createElement('script');
 js.type='text/javascript';
 js.onload = function(){
 new VConsole();
 };
 js.onerror = function(e){
 alert("vonsole.js load error,err:" + e);
 };
 js.src = "//v1-ab.cdn-static.cn/editor/js/vconsole.min.js";
 obj.appendChild(js);
 }
 })();

 var jsVersion = '2021519103916',
 cssVersion = '202031911342';
 </script></head><body do-page-width="1" class="fr-element fr-view do-page-931935




	
		
		
			do-kf-phoneBottom do-kf-icon-box
		
		
	
" do-phone-nav="do-drop-full" do-phonenav-slip-direction="left-to-right" do-phonenav-btnalign="do-navBtn-right"><div style="display: none"><img src="/static/picture/57939_knlcldz4.png"></div><div class="do-nav-mwp do-nav-phone"><input type="checkbox" id="do-m-menustate" class="do-m-menustate"><div class="do-nav-m"><div class="do-nav-m-title animate"><div class="do-site-name"><h3><a href="index.html"><img class="animate" src="/static/picture/57939_knlcldz41.png" alt="四川凯聚鑫建设工程有限公司"></a></h3></div><div class="do-m-menustate do-btn-line do-nav-btn"><label class="do-m-menu-btn" for="do-m-menustate"><span></span><span></span><span></span></label></div></div><div class="do-phoneNav-overlay"></div><div class="do-nav-m-bar animate"><ul class="do-nav-m-ul clearfix"><li class="nav930803" data-id="930803"><a href="index.html"><span>首页</span></a></li><li class="nav932104" data-id="932104"><a href="jkhl.html"><span>基坑护栏</span></a><input type="checkbox" id="inputNavSub932104" class="do-m-menustate do-m-sub"><label for="inputNavSub932104" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav932105" data-id="932105"><a href="932105.html"><span>定型化防护栏</span></a></li><li class="nav932155" data-id="932155"><a href="932155.html"><span>施工防护栏</span></a></li><li class="nav932157" data-id="932157"><a href="932157.html"><span>标准化防护栏</span></a></li><li class="nav932161" data-id="932161"><a href="jkfhw1.html"><span>基坑防护网</span></a></li><li class="nav932167" data-id="932167"><a href="dtfhm.html"><span>电梯防护门</span></a></li></ul></li><li class="nav932170" data-id="932170"><a href="xghl.html"><span>锌钢护栏</span></a></li><li class="nav932173" data-id="932173"><a href="hlw.html"><span>护栏网</span></a><input type="checkbox" id="inputNavSub932173" class="do-m-menustate do-m-sub"><label for="inputNavSub932173" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav932238" data-id="932238"><a href="qcwl.html"><span>球场围栏</span></a></li><li class="nav932240" data-id="932240"><a href="jchlw.html"><span>机场护栏网</span></a></li><li class="nav932176" data-id="932176"><a href="cjglw.html"><span>车间隔离网</span></a></li><li class="nav932177" data-id="932177"><a href="fdw.html"><span>防盗网/防盗刺网</span></a></li><li class="nav932178" data-id="932178"><a href="lhghw.html"><span>绿化勾花网</span></a></li><li class="nav932179" data-id="932179"><a href="bkhlw.html"><span>边框护栏网</span></a></li><li class="nav932180" data-id="932180"><a href="932180.html"><span>铁路护栏网</span></a></li></ul></li><li class="nav932249" data-id="932249"><a href="bpfhw.html"><span>边坡防护网</span></a><input type="checkbox" id="inputNavSub932249" class="do-m-menustate do-m-sub"><label for="inputNavSub932249" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav932250" data-id="932250"><a href="932250.html"><span>边坡绿化网</span></a></li><li class="nav932251" data-id="932251"><a href="tkw.html"><span>钛克网</span></a></li><li class="nav932252" data-id="932252"><a href="bdfhw.html"><span>被动网</span></a></li><li class="nav932253" data-id="932253"><a href="zdfhw.html"><span>主动网</span></a></li><li class="nav932254" data-id="932254"><a href="932254.html"><span>GPS2主动网</span></a></li><li class="nav932255" data-id="932255"><a href="rxfhw.html"><span>sns柔性网</span></a></li></ul></li><li class="nav930832" data-id="930832"><a href="dlhl.html"><span>道路护栏</span></a><input type="checkbox" id="inputNavSub930832" class="do-m-menustate do-m-sub"><label for="inputNavSub930832" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav932241" data-id="932241"><a href="932241.html"><span>桥梁护栏</span></a></li><li class="nav932242" data-id="932242"><a href="932242.html"><span>道路隔离护栏</span></a></li><li class="nav933862" data-id="933862"><a href="933862.html"><span>二代隔离护栏</span></a></li><li class="nav932243" data-id="932243"><a href="932243.html"><span>防撞护栏</span></a></li><li class="nav932244" data-id="932244"><a href="szhl.html"><span>市政护栏</span></a></li><li class="nav932245" data-id="932245"><a href="932245.html"><span>京式护栏</span></a></li><li class="nav932247" data-id="932247"><a href="932247.html"><span>防眩目护栏</span></a></li><li class="nav932248" data-id="932248"><a href="932248.html"><span>广告护栏板</span></a></li></ul></li><li class="nav933163" data-id="933163"><a href="cpzx.html"><span>产品中心</span></a><input type="checkbox" id="inputNavSub933163" class="do-m-menustate do-m-sub"><label for="inputNavSub933163" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav931931" data-id="931931"><a href="jzwp.html"><span>建筑网片</span></a></li><li class="nav933876" data-id="933876"><a href="gjwp.html"><span>钢筋网片</span></a></li><li class="nav933161" data-id="933161"><a href="933161.html"><span>石笼网</span></a></li><li class="nav933162" data-id="933162"><a href="933162.html"><span>钢丝绳</span></a></li><li class="nav934078" data-id="934078"><a href="934078.html"><span>钢格板</span></a></li><li class="nav934086" data-id="934086"><a href="934086.html"><span>爬架网</span></a></li><li class="nav933863" data-id="933863"><a href="933863.html"><span>楼梯扶手</span></a></li><li class="nav933874" data-id="933874"><a href="933874.html"><span>阳台护栏</span></a></li></ul></li><li class="nav933125" data-id="933125"><a href="933125.html"><span>厂家风采</span></a></li><li class="nav931933" data-id="931933"><a href="931933.html"><span>工程案例</span></a></li><li class="nav931934" data-id="931934"><a href="931934.html"><span>新闻动态</span></a></li><li class="nav931935 active" data-id="931935"><a href=""><span>联系我们</span></a></li></ul><div class="do-site-name animate do-nav-m-bar-name"><h3></h3><h3><a href="index.html"><img class="animate"></a></h3></div></div></div></div><div class="do-adrift"><div class="do-popwximg" style="display:none"><div class="do-middle"><div class="do-middle-center"><img src="/static/picture/62777_kpxex0mr.jpg" width="160"><p class="wxphone">长按二维码关注微信加好友</p></div></div><i class="icon-close do-close"></i></div><input type="checkbox" id="do-online-service" class="do-hide"><div class="do-online-service"><label for="do-online-service" class="do-online-service-btn icon-bubbles do-open do-bg-blue1"></label><div class="do-box"><div class="do-box-title do-bg-blue1">在线咨询<label for="do-online-service" class="icon-close do-close"></label></div><div class="do-box-con"><div class="do-box-item qq"><a href="javascript:;" target="_blank" class="on" title="" id="bizQQ_WPA"><i class="icon-qq"></i><span>532178620</span><em>在线QQ</em></a></div><div class="do-box-item mail"><a href="mailto:532178620@qq.com" title="" class="on"><i class="icon-mail"></i><span>532178620@qq.com</span></a></div><div class="do-box-item tel"><h6><i class="icon-phone"></i> 电话</h6><h4><a href="tel:15388189989"><i class="icon-phone"></i><span>15388189989</span><em>拨打</em></a></h4></div><div class="do-box-item sms"><a href="javascript:;"><i class="icon-mail"></i><em>发送短信</em></a></div><div class="do-box-item qr"><a href="javascript:;" class="weixinBtn phoneOff"><i class="icon-weixin"></i><em>微信</em></a><div class="wximg phoneNone"><img src="/static/picture/62777_kpxex0mr.jpg" width="100%"><p class="wxpc">微信扫一扫</p><p class="wxphone">长按二维码关注微信加好友</p></div></div></div></div></div><div class="do-gotop" title="返回顶部"><i class="icon-to-top"></i></div></div><div class="do-container animate"><div class=" do-section fp-auto-height do-header" do-header-fixed="" data-fullname="TOP"><div class="do-area do-area-full" id="header_931935_0"><div class="do-area-bg"><div class="do-area-bg-conter"><div class="bgcolor"></div></div></div><div id="header_0" class="do-row do-row-one"><div class="do-row

 "><div class="do-col-12 do-H-c-76-77" id='H-c-76-77'><div class="do-panelcol"><div class="do-block
 
 do-rows"><div class="do-row

"><div class="do-col-12 do-H-c-76-77-78-81" id='H-c-76-77-78-81'><div class="do-panelcol"><div class="do-block
 
 do-rows"><div class="do-row

 huzi-top"><div class="do-col-6 do-H-c-0-1-2-3-4-156" id='H-c-0-1-2-3-4-156'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-logo do-1l6yme"><div do-logo="" class="do-logo"><div class="z-logo align-center size16"><a href="index.html" title=""><img src="/static/picture/57939_knlcldz42.png" alt=""></a></div></div></div></div></div><div class="do-col-3 do-H-c-0-1-2-3-4-127" id='H-c-0-1-2-3-4-127'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-text do-1l3ho3"><div class="do-text-1l3ho3"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p style="text-align: center; line-height: 1.2;"><strong><span style="font-family: &quot;Microsoft YaHei&quot;, 微软雅黑, MicrosoftJhengHei, 华文细黑, STHeiti, MingLiu; font-size: 30px; color: rgb(0, 114, 194);">专注品质，保障服务</span></strong></p><p style="text-align: center; line-height: 1.2;"><span style="font-size: 18px;">愿我的服务和质量与您随时相伴</span></p></div></div></div></div></div></div></div><div class="do-col-1 do-H-c-0-1-2-3-4-144" id='H-c-0-1-2-3-4-144'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-space do-1l6ymi"><div class="do-element-space pc" style="padding-top:8.664259927797833%;"></div><div class="do-element-space phone" style="padding-top:5%;"></div></div><div class="do-block
 
 
 
 
 do-image do-1l6ymg"><div class="do-element-image do-element-media


"><div class="do-element-image-content do-html" style="padding-top:53.57142857142857%;"><div class="do-image-href do-img-animation sizeimg3 "><div class="do-middle"><div class="do-middle-center"><img class="scrollLoading" data-src="//v1.cdn-static.cn/2021/3/26/57939_kmq31jv8.jpg?imageView2/2/w/224/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" alt=""></div></div></div></div></div></div><div class="do-block
 
 
 
 
 do-space do-1l6ymh"><div class="do-element-space pc" style="padding-top:9.821428571428571%;"></div><div class="do-element-space phone" style="padding-top:5%;"></div></div></div></div><div class="do-col-2 do-H-c-0-1-2-3-4-137" id='H-c-0-1-2-3-4-137'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-text do-1l3ho1"><div class="do-text-1l3ho1"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p><span style="font-size: 28px;"><strong>18980777678</strong></span></p></div></div></div></div></div></div></div></div></div><div class="do-block
 
 
 
 
 do-nav do-1l1buz"><div class="z-nav align-center"><div class="z-nav-bar"><div class="z-nav-container"><ul class="z-nav-conter clearfix"><li class="nav930803" data-id="930803"><a href="index.html"><span>首页</span></a></li><li class="nav932104" data-id="932104"><a href="jkhl.html"><span>基坑护栏</span></a><input type="checkbox" id="inputNavSub932104" class="do-m-menustate do-m-sub"><label for="inputNavSub932104" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav932105" data-id="932105"><a href="932105.html"><span>定型化防护栏</span></a></li><li class="nav932155" data-id="932155"><a href="932155.html"><span>施工防护栏</span></a></li><li class="nav932157" data-id="932157"><a href="932157.html"><span>标准化防护栏</span></a></li><li class="nav932161" data-id="932161"><a href="jkfhw1.html"><span>基坑防护网</span></a></li><li class="nav932167" data-id="932167"><a href="dtfhm.html"><span>电梯防护门</span></a></li></ul></li><li class="nav932170" data-id="932170"><a href="xghl.html"><span>锌钢护栏</span></a></li><li class="nav932173" data-id="932173"><a href="hlw.html"><span>护栏网</span></a><input type="checkbox" id="inputNavSub932173" class="do-m-menustate do-m-sub"><label for="inputNavSub932173" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav932238" data-id="932238"><a href="qcwl.html"><span>球场围栏</span></a></li><li class="nav932240" data-id="932240"><a href="jchlw.html"><span>机场护栏网</span></a></li><li class="nav932176" data-id="932176"><a href="cjglw.html"><span>车间隔离网</span></a></li><li class="nav932177" data-id="932177"><a href="fdw.html"><span>防盗网/防盗刺网</span></a></li><li class="nav932178" data-id="932178"><a href="lhghw.html"><span>绿化勾花网</span></a></li><li class="nav932179" data-id="932179"><a href="bkhlw.html"><span>边框护栏网</span></a></li><li class="nav932180" data-id="932180"><a href="932180.html"><span>铁路护栏网</span></a></li></ul></li><li class="nav932249" data-id="932249"><a href="bpfhw.html"><span>边坡防护网</span></a><input type="checkbox" id="inputNavSub932249" class="do-m-menustate do-m-sub"><label for="inputNavSub932249" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav932250" data-id="932250"><a href="932250.html"><span>边坡绿化网</span></a></li><li class="nav932251" data-id="932251"><a href="tkw.html"><span>钛克网</span></a></li><li class="nav932252" data-id="932252"><a href="bdfhw.html"><span>被动网</span></a></li><li class="nav932253" data-id="932253"><a href="zdfhw.html"><span>主动网</span></a></li><li class="nav932254" data-id="932254"><a href="932254.html"><span>GPS2主动网</span></a></li><li class="nav932255" data-id="932255"><a href="rxfhw.html"><span>sns柔性网</span></a></li></ul></li><li class="nav930832" data-id="930832"><a href="dlhl.html"><span>道路护栏</span></a><input type="checkbox" id="inputNavSub930832" class="do-m-menustate do-m-sub"><label for="inputNavSub930832" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav932241" data-id="932241"><a href="932241.html"><span>桥梁护栏</span></a></li><li class="nav932242" data-id="932242"><a href="932242.html"><span>道路隔离护栏</span></a></li><li class="nav933862" data-id="933862"><a href="933862.html"><span>二代隔离护栏</span></a></li><li class="nav932243" data-id="932243"><a href="932243.html"><span>防撞护栏</span></a></li><li class="nav932244" data-id="932244"><a href="szhl.html"><span>市政护栏</span></a></li><li class="nav932245" data-id="932245"><a href="932245.html"><span>京式护栏</span></a></li><li class="nav932247" data-id="932247"><a href="932247.html"><span>防眩目护栏</span></a></li><li class="nav932248" data-id="932248"><a href="932248.html"><span>广告护栏板</span></a></li></ul></li><li class="nav933163" data-id="933163"><a href="cpzx.html"><span>产品中心</span></a><input type="checkbox" id="inputNavSub933163" class="do-m-menustate do-m-sub"><label for="inputNavSub933163" class="icon-isSub"></label><ul class="z-nav-sub"><li class="nav931931" data-id="931931"><a href="jzwp.html"><span>建筑网片</span></a></li><li class="nav933876" data-id="933876"><a href="gjwp.html"><span>钢筋网片</span></a></li><li class="nav933161" data-id="933161"><a href="933161.html"><span>石笼网</span></a></li><li class="nav933162" data-id="933162"><a href="933162.html"><span>钢丝绳</span></a></li><li class="nav934078" data-id="934078"><a href="934078.html"><span>钢格板</span></a></li><li class="nav934086" data-id="934086"><a href="934086.html"><span>爬架网</span></a></li><li class="nav933863" data-id="933863"><a href="933863.html"><span>楼梯扶手</span></a></li><li class="nav933874" data-id="933874"><a href="933874.html"><span>阳台护栏</span></a></li></ul></li><li class="nav933125" data-id="933125"><a href="933125.html"><span>厂家风采</span></a></li><li class="nav931933" data-id="931933"><a href="931933.html"><span>工程案例</span></a></li><li class="nav931934" data-id="931934"><a href="931934.html"><span>新闻动态</span></a></li><li class="nav931935 active" data-id="931935"><a href=""><span>联系我们</span></a></li></ul></div></div><div class="z-nav-btn"><span class="line-1"></span><span class="line-2"></span><span class="line-3"></span></div></div><style>
 .z-nav { background-color:rgb(0, 114, 194);text-align:center; }.z-nav-conter > li.active > a,.z-nav-conter > li:hover > a { background-color:rgba(255, 255, 255, 0.21);color:rgb(255, 255, 255); }.lt-ie9 .z-nav-conter > li.active > a,.z-nav-conter > li:hover > a { filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#33ffffff,endColorstr=#33ffffff) }.z-nav-conter > li:hover > a { background-color:rgb(255, 255, 255);color:rgb(0, 114, 194); }.z-nav-conter > li > a { color:rgb(255, 255, 255);font-size:16px;line-height:2.03em; }
</style></div></div></div></div></div></div></div></div></div></div></div><div class="do-section fp-auto-height do-banner" data-fullname="BANNER"><div class="do-area do-area-full" id="banner_931935_0"><div class="do-area-bg "><div class="do-area-bg-conter"><div class="bgcolor"></div></div></div><div id="banner_0" class="do-row do-row-one "><div class="do-row

 "><div class="do-col-12 do-B-c-67-68" id='B-c-67-68'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-slide do-1l3hnx"><div class="do-element-swiper do-element-slide

" style="padding-top:30.560271646859082%;"><div class="do-element-swiper-content swiper-container" data-effect="slide" id="slide_1l3hnx"><div class="swiper-wrapper"><div class="swiper-slide"><div class="do-element-slide-img"><div class="do-slide-bg"><div class="do-slide-bg-conter bgimg" title="" style="background-image:url(/static/image/57939_kmpy273k.jpg);

 

 "></div></div></div></div></div></div></div></div></div></div></div></div></div></div><div class="do-body"><div class="do-section do-area" id="area_931935_0" data-fullname=""><div class="do-area-bg "><div class="do-area-bg-conter"><div class="bgcolor"></div></div></div><div id="area_0" class="do-row do-row-one "><div class="do-row

 "><div class="do-col-12 do-D-c-292-293" id='D-c-292-293'><div class="do-panelcol"><div class="do-block
 
 do-rows"><div class="do-row

 "><div class="do-col-12 do-D-c-100-101" id='D-c-100-101'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-text do-1l2hrz"><div class="do-text-1l2hrz"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p>快速通道：首页 &nbsp;联系我们</p></div></div></div></div></div><div class="do-block
 
 
 
 
 do-space do-1l2gzl"><div class="do-element-space pc" style="padding-top:2.5%;"></div><div class="do-element-space phone" style="padding-top:16.400000000000002%;"></div></div><div class="do-block
 
 
 
 
 do-text do-1l2gzk"><div class="do-text-1l2gzk"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p style="text-align: center;"><span style="font-size: 30px;"><strong><span style="color: rgb(0, 114, 194);">联系我们</span></strong>·凯聚新</span></p></div></div></div></div></div><div class="do-block
 
 
 
 
 do-text do-1l2gzj"><div class="do-text-1kzw93"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p style="text-align: center;">——————————</p></div></div></div></div></div><div class="do-block
 
 
 
 
 do-text do-1l2gzi"><div class="do-text-1l02wz"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p style="text-align: center;"><span style="font-size: 16px;">—选择凯聚新，四川凯聚新建设工程有限公司—</span></p></div></div></div></div></div><div class="do-block
 
 
 
 
 do-space do-1l2gzh"><div class="do-element-space pc" style="padding-top:3.3333333333333335%;"></div><div class="do-element-space phone" style="padding-top:5%;"></div></div><div class="do-block
 
 
 
 
 do-list do-1l8oik"><div class="do-element-media x
 num3 phoneRows2
 listvm"><div class="do-element-media-content " id="swiper_1l8oik" data-rows="3" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1"><ul class="do-element-media-ul x do-content-list "><li class="do-element-media-li
 
 
 
 
 
 
 " data-wow-delay=".0s"><div class="do-element-media-conter clearfix do-caption "><div class="do-media-image-box o-mask"><div class="do-media-image"><div class="do-media-image-conter sizeimg "><div class="do-middle"><div class="do-middle-center"><img class="scrollLoading" data-src="//v1.cdn-static.cn/2017/2/25/1587_izkpi8wu.png?imageView2/2/w/288/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" alt=""></div></div></div></div></div><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>公司地址</p></div><div class="do-html-content des"><p><span style="font-size: 12px;">四川省成都市金牛区金丰路6号7栋1单元16层11603号</span></p></div></div></div></div></div></li><li class="do-element-media-li
 
 
 
 
 
 
 " data-wow-delay=".1s"><div class="do-element-media-conter clearfix do-caption "><div class="do-media-image-box o-mask"><div class="do-media-image"><div class="do-media-image-conter sizeimg "><div class="do-middle"><div class="do-middle-center"><img class="scrollLoading" data-src="//v1.cdn-static.cn/2017/2/25/1587_izkpi8x0.png?imageView2/2/w/288/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" alt=""></div></div></div></div></div><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>联系电话</p></div><div class="do-html-content des"><p><span style="color: rgb(51, 51, 51);">18980777678</span></p></div></div></div></div></div></li><li class="do-element-media-li
 
 
 
 
 
 
 " data-wow-delay=".2s"><div class="do-element-media-conter clearfix do-caption "><div class="do-media-image-box o-mask"><div class="do-media-image"><div class="do-media-image-conter sizeimg "><div class="do-middle"><div class="do-middle-center"><img class="scrollLoading" data-src="//v1.cdn-static.cn/2017/2/25/1587_izkpi8wz.png?imageView2/2/w/288/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" alt=""></div></div></div></div></div><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>电子邮箱</p></div><div class="do-html-content des"><p><span style="font-size: 12px;">532178620@qq.com</span></p></div></div></div></div></div></li></ul></div></div><style>.do-1l8oik .do-middle-center img { width:35%; }.do-1l8oik .do-title .title { font-size:18px;line-height:1.50em;text-align:left; }</style></div><div class="do-block
 
 
 
 
 do-space do-1l2gzf"><div class="do-element-space pc" style="padding-top:1.7500000000000002%;"></div><div class="do-element-space phone" style="padding-top:17.1%;"></div></div></div></div></div></div></div></div></div></div></div><div class="do-section do-area" id="area_931935_1" data-fullname=""><div class="do-area-bg "><div class="do-area-bg-conter"><div class="bgcolor"></div></div></div><div id="area_1" class="do-row do-row-one "><div class="do-row

 "><div class="do-col-12 do-D-c-59-60" id='D-c-59-60'><div class="do-panelcol"><div class="do-block
 
 do-rows"><div class="do-row

"><div class="do-col-6 do-D-c-27-28-78" id='D-c-27-28-78'><div class="do-panelcol"><div data-wow-duration="1s" data-wow-delay="0.5s" data-wow-iteration="1" class="do-block
 
 
 
 
 wow fadeInUp
 
 
 
 do-map do-1l2blp"><div class="do-element-map" style="padding-top:18.833333333333332%;"><div class="do-element-map-content" id="map_1l2blp"></div></div><script>
$(function() {
 var config = {
 center: [ 104.049477 , 30.727009 ],
 doubleClickZoom:true,
 zoom: 10 
 };

 
 config.dragEnable = true;
 
 
 config.scrollWheel = true;
 

 var map = new AMap.Map("map_1l2blp",config);


 map.setLang("zh_cn");









 var marker = new AMap.Marker({
 position: [ 104.049477 , 30.727009 ],
 map: map});

var infoWindow,info = [];

 info.push("<div class="do-mapInfo-content"><b>" + "四川凯聚鑫建设工程有限公司" + "</b>");


 info.push("<span>电话:</span>" + "18980777678");



 info.push("<span>地址:</span>" + "四川省成都市金牛区金丰路6号7栋1单元16层11603号" + "</div></div>");
 infoWindow = new AMap.InfoWindow({
 offset: new AMap.Pixel(0, -30),
 content: info.join("<br/>") 
 });
 setTimeout(function(){
 infoWindow.open(map, [ 104.049477 , 30.727009 ]);
 },1000)





})
</script></div></div></div><div class="do-col-6 do-D-c-27-28-75-76" id='D-c-27-28-75-76'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-forms do-1l2htq"><div class="do-element-forms 
ly-form-border

 
 
 align-left 
 
 
 do-forms-label-hide
 

"><div class="do-noAdapt-content
 
 

 

 
 md
 

 

 

 
 
 
 list
 


 "><form action='/forms/data/83008/0f135dcb-2642-493f-b1a9-8dd065de90fa' data-id="0f135dcb-2642-493f-b1a9-8dd065de90fa" id="item_0f135dcb-2642-493f-b1a9-8dd065de90fa" novalidate="" method="post" class="form do-forms do-product-box list" data-gourl="" data-v="true" onsubmit="return false;"><div class="do-form-group form-input do-formitem0 do-form-item"><label for="form_id_姓名">姓名<span style="color:red">*</span></label><input type="text" class="form-control required" name="姓名" datatype="*" nullmsg="姓名" id="form_id_姓名" placeholder="姓名"></div><div class="do-form-group form-input do-formitem1 do-form-item"><label for="form_id_电话">电话<span style="color:red">*</span></label><input type="text" class="form-control required" name="电话" datatype="
	phone
	" errormsg="请输入正确的联系方式！" nullmsg="电话" id="form_id_电话" placeholder="电话"></div><div class="do-form-group form-email do-formitem2 do-form-item"><label for="form_id_邮箱">邮箱<span style="color:red">*</span></label><input type="email" class="form-control" name="邮箱" id="form_id_邮箱" datatype="e" nullmsg="请选择邮箱！" value="" placeholder="邮箱"></div><div class="do-form-group form-textarea do-formitem3 do-form-item"><label for="form_id_内容">内容<span style="color:red">*</span></label><textarea name="内容" class="form-control" datatype="*" nullmsg="内容" placeholder="内容"></textarea></div><div class="do-form-group form-captcha"><label>验证<span style="color:red">*</span></label><div id="forms_captcha_0f135dcb-2642-493f-b1a9-8dd065de90fa" class="forms_captcha captcha_0f135dcb-2642-493f-b1a9-8dd065de90fa" data-lang="zh-cn"><input type='hidden' name="geetest_server_status"></div></div><div class="do-form-group form-button"><input type="submit" id="btn_0f135dcb-2642-493f-b1a9-8dd065de90fa" class="btn btn-success btn-lg btn-block
 
 
 do-bg-blue1
 
 
 " value='立即提交'></div></form></div></div><style>.do-1l2htq .do-element-forms .do-form-item { padding-right:10px;width:100%; }</style><script type="text/javascript">
var submiting = '提交中';
var submitSuccess = '提交成功';
var submitSuccessText = '您已提交成功！';
var submit = '提交';
var postage = '邮费';
var forms_captcha_handler = {};
</script></div></div></div></div></div><div class="do-block
 
 
 
 
 do-space do-1l2blk"><div class="do-element-space" style="padding-top:3.3333333333333335%;"></div></div></div></div></div></div></div></div><div class="do-footer"><div class="do-area" id="footer_931935_0"><div class="do-area-bg"><div class="do-area-bg-conter"><div class="bgcolor"></div></div></div><div id="footer_0" class="do-row do-row-one"><div class="do-row

 "><div class="do-col-12 do-D-c-47-48" id='D-c-47-48'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-space do-1l34vc"><div class="do-element-space pc" style="padding-top:6.666666666666667%;"></div><div class="do-element-space phone" style="padding-top:16.400000000000002%;"></div></div><div class="do-block
 
 do-rows"><div class="do-row

"><div class="do-col-4 do-D-c-34-35-59" id='D-c-34-35-59'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-text do-1l34vb"><div class="do-text-1l34vb"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p style="line-height: 1;"><span style="font-family: SimHei; font-size: 24px; color: rgb(255, 255, 255);"><strong>联系我们</strong></span></p></div></div></div></div></div><div class="do-block
 
 
 
 
 do-hr do-1l39jf"><div class="do-element-line default "><div class="do-element-line-content"><div class="do-middle"><div class="do-middle-center"><hr style="border-color:rgb(254, 253, 253);"></div></div></div></div></div><div class="do-block
 
 
 
 
 do-space do-1l34va"><div class="do-element-space pc" style="padding-top:5.221932114882506%;"></div><div class="do-element-space phone" style="padding-top:5%;"></div></div><div class="do-block
 
 
 
 
 do-text do-1l34v9"><div class="do-text-1l34v9"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p style="line-height: 2;"><span style="color: rgb(255, 255, 255);"><span style="font-size: 16px;"><span style="font-family: 'Microsoft YaHei',微软雅黑,'MicrosoftJhengHei',华文细黑,STHeiti,MingLiu;">电话：</span></span></span><span style="font-size: 16px; color: rgb(255, 255, 255);">18980777678</span></p><p style="line-height: 2;"><span style="font-family: &quot;Microsoft YaHei&quot;, 微软雅黑, MicrosoftJhengHei, 华文细黑, STHeiti, MingLiu; font-size: 16px; color: rgb(255, 255, 255);">邮箱：532178620@qq.com</span></p><p style="line-height: 2;"><span style="font-family: &quot;Microsoft YaHei&quot;, 微软雅黑, MicrosoftJhengHei, 华文细黑, STHeiti, MingLiu; font-size: 16px; color: rgb(255, 255, 255);">地址：</span><span style="font-size: 16px; color: rgb(255, 255, 255);">四川省成都市金牛区金丰路6号7栋1单元16层 &nbsp; &nbsp; &nbsp;11603号</span></p></div></div></div></div></div></div></div><div class="do-col-8 do-D-c-34-35-56-57" id='D-c-34-35-56-57'><div class="do-panelcol"><div class="do-block
 
 do-rows"><div class="do-row

"><div class="do-col-4 do-D-c-34-35-56-57-66" id='D-c-34-35-56-57-66'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-text do-1l34v8"><div class="do-text-1l34v8"><div class="do-element-text do-element-general"><div class="do-element-text-content do-html"><div class="do-html-content"><p style="line-height: 1;"><span style="font-family: SimHei; font-size: 24px; color: rgb(255, 255, 255);"><strong>快捷导航</strong></span></p></div></div></div></div></div><div class="do-block
 
 
 
 
 do-hr do-1l39je"><div class="do-element-line default "><div class="do-element-line-content"><div class="do-middle"><div class="do-middle-center"><hr style="border-color:rgb(253, 253, 253);"></div></div></div></div></div><div class="do-block
 
 
 
 
 do-space do-1l39jg"><div class="do-element-space" style="padding-top:5%;"></div></div><div class="do-block
 
 
 
 
 do-list do-1l6ymc"><div class="do-element-media x
 num3 phoneRows2
 "><div class="do-element-media-content md " id="swiper_1l6ymc" data-rows="3" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1"><ul class="do-element-media-ul x do-content-grid "><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932104
 " data-wow-delay=".0s"><a href="jkhl.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>基坑护栏</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932170
 " data-wow-delay=".1s"><a href="xghl.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>锌钢护栏</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932173
 " data-wow-delay=".2s"><a href="hlw.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>护栏网</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932249
 " data-wow-delay=".3s"><a href="bpfhw.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>边坡防护网</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-930832
 " data-wow-delay=".4s"><a href="dlhl.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>道路护栏</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-933163
 " data-wow-delay=".5s"><a href="cpzx.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>产品中心</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-933125
 " data-wow-delay=".6s"><a href="933125.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>厂区风采</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-931933
 " data-wow-delay=".7s"><a href="931933.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>工程案例</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-931934
 " data-wow-delay=".8s"><a href="931934.html"><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>新闻动态</p></div></div></div></div></div></a></li><li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 active
 
 pgid-931935
 " data-wow-delay=".9s"><a href=""><div class="do-element-media-conter clearfix do-caption-noimg "><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p>联系我们</p></div></div></div></div></div></a></li></ul></div></div><style>.do-1l6ymc .do-middle-center img { width:100%; }.do-1l6ymc .do-title .title { font-size:14px;line-height:1.74em;text-align:center;color:rgb(252, 250, 250); }</style></div><div class="do-block
 
 
 
 
 do-space do-1l34v7"><div class="do-element-space pc" style="padding-top:7.246376811594203%;"></div><div class="do-element-space phone" style="padding-top:5%;"></div></div></div></div><div class="do-col-4 do-F-c-87-88-90-96-97-116" id='F-c-87-88-90-96-97-116'><div class="do-panelcol"><div class="do-block
 
 
 
 
 do-space do-1l39j1"><div class="do-element-space pc" style="padding-top:12.140575079872203%;"></div><div class="do-element-space phone" style="padding-top:5%;"></div></div><div class="do-block
 
 
 
 
 do-list do-1l39j3"><div class="do-element-media x
 num1 phoneRows2
 "><div class="do-element-media-content " id="swiper_1l39j3" data-rows="1" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1"><ul class="do-element-media-ul x do-listImgPreview do-content-grid "><li class="do-element-media-li
 
 
 
 
 
 
 " data-wow-delay=".0s"><div class="do-element-media-conter clearfix do-caption "><div class="do-media-image-box o-mask"><div class="do-media-image" style="padding-top:34.946236559139784%;"><div class="do-media-image-conter sizeimg "><div class="do-middle"><div class="do-middle-center"><img class="scrollLoading" data-src="//v1.cdn-static.cn/2021/6/15/62777_kpxex0mr.jpg?imageView2/2/w/1125/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" alt="成都锌钢护栏"></div></div></div></div></div><div class="do-title do-html-content"><div class="do-title-body"><div class="do-title-content do-html-content"><div class="do-html-content title"><p style="line-height: 1; text-align: center;"><span style="font-family: &quot;Microsoft YaHei&quot;, 微软雅黑, MicrosoftJhengHei, 华文细黑, STHeiti, MingLiu; font-size: 14px; color: rgb(255, 255, 255);">扫码立即咨询</span></p></div></div></div></div></div></li></ul></div></div><style>.do-1l39j3 .do-middle-center img { width:35%; }</style></div></div></div></div></div></div></div></div></div><div class="do-block
 
 
 
 
 do-space do-1l34v4"><div class="do-element-space pc" style="padding-top:1.6666666666666667%;"></div><div class="do-element-space phone" style="padding-top:5%;"></div></div><div class="do-block
 
 
 
 
 do-hr do-1l34v3"><div class="do-element-line default " style="padding-top:-1.3333333333333335%;"><div class="do-element-line-content"><div class="do-middle"><div class="do-middle-center"><hr style="border-color:rgb(255, 255, 255);"></div></div></div></div></div></div></div></div></div></div></div><div class="do-developers">
 版权所有© 四川凯聚鑫建设工程有限公司 &nbsp;&nbsp; 
 
 技术支持：
 
 <a href="javascript:;" title="成都智网创联网络科技有限公司" target="_blank" rel="nofollow"><span>成都智网创联网络科技有限公司</span></a></div><script>
var _hmt = _hmt || [];
(function() {
 var hm = document.createElement("script");
 hm.src = "https://hm.baidu.com/hm.js?4b0fff422353306d2f96d551796b0178";
 var s = document.getElementsByTagName("script")[0]; 
 s.parentNode.insertBefore(hm, s);
})();
</script><style>
body .do-developers, .do-developers{color:#666!important;width:100%!important;min-height: 38px!important;}
body .do-developers a, .do-developers a{color:#666!important;display: inline-block!important;}
body .do-developers a:hover, .do-developers a:hover{color:#000!important;}
body .do-developers, .do-developers{display: block!important; border-top:1px solid #ecebeb!important; background:#f3f3f3!important;padding:12px!important;text-align: center!important;font-size: 13px!important;line-height: 100%!important;opacity: 1!important;text-indent:0!important}
body .do-developers i, .do-developers i{font-size:13px!important;vertical-align: middle;position: relative;top:-1px}
body .do-developers *, .do-developers *{opacity: 1!important;text-indent:0!important;display: inline-block!important;}



</style></div><script src="/static/js/js.js" merge="true" crossorigin=""></script><script src="/static/js/wow.min.js" crossorigin=""></script><script src="/static/js/head.js" crossorigin=""></script><script src="/static/js/common.js" crossorigin=""></script><script src="/static/js/gt.js" crossorigin=""></script><script src="/static/js/1.js" crossorigin=""></script><script src="/static/js/swipers.js" crossorigin=""></script><script src="/static/js/maps.js" crossorigin=""></script><script src="/static/js/zhuzi-statistic.js"></script><script type="text/javascript">

$(function(){
 
 

 var wow = new WOW({
 animateClass: 'animated',
 offset: 100,
 callback:function(box) { }
 });
 wow.init();

 
 if(isWeiXin() && bIsAndroid){
 var fullArea = $(".do-area-fullHeight .do-row-one > .do-row, .do-slide-full");
 fullArea.css('min-height', $(window).height());
 }

 if(head.desktop){
 if(!_vm.online) $("#do-online-service").prop("checked",true);
 }else{
 $("#do-online-service").prop("checked",false);
 }

 
 if(bIsAndroid){
 $(".do-area-videobg").find("video").remove();
 var vodbgObj = $(".do-area-videobg .do-area-bg-conter");
 vodbgObj.each(function(){
 $(this).css('background-image','url("'+$(this).data("vodbg")+'")');
 });
 }

 
 var weixinBtn = $(".weixinBtn"),
 popwximg = $(".do-popwximg");
 if(weixinBtn.length){
 weixinBtn.on("click",function(e){
 popwximg.show();
 });
 popwximg.on("click",".do-close",function(){
 popwximg.hide();
 });
 }

 layer.config({
 path: '//v1-ab.cdn-static.cn/editor/js/layer/',
 extend: ['skin/style.css'], 
 skin: 'layer-zhuzi' 
 });
 

});

if(typeof _hmt == 'undefined'){
 var _hmt = _hmt || [];
 (function() {
 var hm = document.createElement("script");
 
 hm.src = "https://hm.baidu.com/hm.js?03e4f2f8489d3cb343fc1c99966f477b";
 var s = document.getElementsByTagName("script")[0];
 s.parentNode.insertBefore(hm, s);
 })();
}
</script></body></html>
