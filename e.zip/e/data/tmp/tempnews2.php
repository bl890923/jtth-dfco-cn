<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?=$grpagetitle?> - <?=$public_r[sitename]?></title>
<meta name="description" content="<?=$grpagetitle?>">
<meta name="keywords" content="<?=$ecms_gr[keyboard]?>">
<script src="/static/js/jquery-1.11.3.min.js"></script>
<script src="/static/js/function.js"></script>
<link rel="shortcut icon" href="/static/image/logo.ico" type="image/x-icon">
<link href="/static/css/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/mobile/js/pagemode.js"></script>

</head>
<body>

<div class="top">
  <div class="center"><a href="javascript:;"><img src="/static/picture/logo.jpg" alt="基坑护栏"></a> </div>
</div>
<div class="nav">
  <ul class="center">
    <li class="on"></li>
    <li><a href="/">网站首页</a></li>
    <li><a href="/cpzx/szhl/" rel="nofollow">市政护栏</a></li>
    <li><a href="/cpzx/bpfh/" rel="nofollow">边坡防护</a></li>
    <li><a href="/cpzx/spz/" rel="nofollow">声屏障</a></li>
    <li><a href="/cpzx/wqhl/" rel="nofollow">围墙护栏</a></li>
    <li><a href="/gywm/gcal/" rel="nofollow">工程案例</a></li>
    <li><a href="/gywm/xwdt/" rel="nofollow">新闻动态</a></li>
    <li><a href="/gywm/gsjj/" rel="nofollow">公司简介</a></li>
    <li><a href="/gywm/lxwm/" rel="nofollow">联系我们</a></li>
  </ul>
</div>
<script>
function nav(){
	var navs = $(".nav ul li a");
	for(var i = 0; i < navs.length; i ++){
		runs(i);	
	}
	function runs(i){
		$(".nav ul li a:eq("+i+")").hover(function(){
			$(".nav .on").css({ left:i*10+"%" });
		},function(){
			$(".nav .on").css({ left:"-12.5%" });
		});
	}
	
}
nav();

</script>


<div class="xt1"><a href="javascript:;"></a></div>
<div class="main">
  <div class="main_con">
  
    <div class="left">
    
    
    
      <h3>产品中心</h3>
      
<ul>

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select classid,classname from {$dbtbpre}enewsclass where bclassid=1 order by myorder,classid ASC",0,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<?php
$classurl=sys_ReturnBqClassname($bqr,9);//取得栏目地址
?>
        <li><a href="<?=$classurl?>"><?=$bqr[classname]?></a></li>
<?php
}
}
?>
</ul>



    </div>
    

    <script>

  	for(var i = 0; i < $(".left li").length; i++){
  		var H = window.location.href;
  		if(H == $(".left li a")[i].href){
  			$(".left li")[i].className = "on";
  		}
  	}


  </script>


    <div class="right">
      <div class="plc">
        <p><span>当前位置：<?=$grurl?></span><?=$class_r[$ecms_gr[classid]][classname]?></p>
      </div>
      <div class="cptit">
        <h1><?=$ecms_gr[title]?></h1>
      </div>
      <div class="cpms">
      
<?=strstr($ecms_gr[newstext],'[!--empirenews.page--]')?'[!--newstext--]':$ecms_gr[newstext]?>

        <p><br>
        </p>
      </div>


      <div class="xgcp">
        <div class="xgtit">
          <p>相关产品</p>
        </div>
        <ul>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq('selfinfo',4,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<li><a href=""<?=$bqsr['titleurl']?>"><img alt="<?=$bqr['title']?>" src="<?=$bqr['titlepic']?>"><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></li>
<?php
}
}
?>
        </ul>
      </div>
      <div class="xgxw">
        <div class="xgtit">
          <p>相关新闻</p>
        </div>
        <ul>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(43,5,0,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
          <li><span><?=date('Y-m-d',$bqr[newstime])?></span><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></li>
<?php
}
}
?>

        </ul>
      </div>
    </div>
  </div>
</div>

<div class="footer">
<div class="foot_nav">
<div class="foot_nav_nr"> 
<a href="/">网站首页</a>
<a href="/cpzx/szhl/" rel="nofollow">市政护栏</a>
<a href="/cpzx/bpfh/" rel="nofollow">边坡防护</a>
<a href="/cpzx/spz/" rel="nofollow">声屏障</a>
<a href="/cpzx/wqhl/" rel="nofollow">围墙护栏</a>
<a href="/gywm/gcal/" rel="nofollow">工程案例</a>
<a href="/gywm/xwdt/" rel="nofollow">新闻动态</a>
<a href="/gywm/gsjj/" rel="nofollow">公司简介</a>
<a href="/gywm/lxwm/" rel="nofollow">联系我们</a>
 </div>
</div>
<div class="foot_con">
<p>版权所有© <?=$public_r[sitename]?>联系人：华经理<?=$public_r[lxdh]?> </p>
<p>电话：<?=$public_r[fwrx]?> 邮箱：<?=$public_r[kfqq]?>@qq.com 地址：<?=$public_r[gsdz]?> 技术支持：<a href="https://www.shunking.cn" rel="nofollow">舜王科技</a> <a href="https://beian.miit.gov.cn/" rel="nofollow"><?=$public_r[icp]?></a>

</p>
</div>
</div>
<script>
	$(function(){
		$(window).scroll(function(){
			if($(window).scrollTop() > 100){
				$(".ewmBox").fadeIn();
			}else{
				$(".ewmBox").fadeOut();
			}
		});
		
	});
</script> 


</body>
</html>
