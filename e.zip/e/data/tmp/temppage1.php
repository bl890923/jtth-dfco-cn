<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html>
<html lang="zh-cn" class="do-cke">
 <head>
 <meta charset="UTF-8">
 <meta name="renderer" content="webkit">
 <meta name="viewport" content="width=device-width,initial-scale=1, minimum-scale=1.0, maximum-scale=1, user-scalable=no, minimal-ui">
 <meta name="applicable-device" content="pc,mobile">
 <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
 <!--[if lt IE 9]><meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE"><![endif]-->
 <title>成都基坑护栏_基坑防护栏杆批发_基坑护栏厂家-四川凯聚鑫建设工程有限公司</title>
 <meta name="robots" content="all">
 <meta name="description" content="四川凯聚鑫建设工程有限公司是一家主要做成都基坑护栏、基坑防护栏杆批发的基坑护栏厂家，公司以完善到位的专业化售前、售中、售后服务赢得了客户的信赖和好评。">
 <meta name="keywords" content="成都基坑护栏,基坑防护栏杆批发,基坑护栏厂家">
 <style>
.wow {
	visibility: hidden;
}
</style>
 <!--[if lt IE 9]><style>.wow {visibility: visible;}</style><![endif]-->
 <link href="static/css/css.css" rel="stylesheet" type="text/css">
 <link href="static/css/css1.css" rel="stylesheet" type="text/css">
 <link href="static/css/style.css" rel="stylesheet" type="text/css">
 <style>
body {
	background-attachment: scroll;
}
.do-site-name *, .do-nav-m-ul li a, .do-nav-m-ul .icon-isSub:before {
	color: rgb(18, 16, 16);
}
#do-m-menustate:checked ~ .do-nav-m .do-nav-m-title, #do-m-menustate ~ .do-nav-m .do-nav-m-title {
	background-color: rgb(255, 255, 255)!important;
}
.do-nav-m-ul > li > a, .do-nav-m-ul > li > ul {
	border-bottom-color: rgb(51, 51, 51);
}
.do-nav-m-bar {
	background-color: rgb(255, 255, 255)!important;
}
.do-nav-m .do-nav-page-name {
	color: rgb(30, 26, 26);
}
.do-m-menu-btn span {
	background-color: rgb(30, 26, 26)!important;
}
.do-nav-m-ul li a {
	font-size: 14px;
}
.do-nav-m .do-site-name img {
	height: 30px;
}
.lt-640 .do-online-service .do-online-service-btn,  .lt-640 .do-kf-phoneDefault .do-online-service .do-box-title,  .lt-640 .do-kf-phoneBottom .do-online-service .do-box-con,  .lt-640 .do-kf-phoneRight .do-online-service .do-box-item {
	background-color: rgb(0, 119, 196)!important;
}
.lt-640 .do-kf-icon-box .do-box-item i,  .lt-640 .do-kf-icon-box .do-box-item em {
	color: rgb(255, 255, 255);
}
.col-autoHeight {
	display: table;
	width: 100%
}
.col-autoHeight > [class*=do-col-] {
display: table-cell;
height: 100%;
float: none;
}
.col-autoHeight > [class*=do-col-] > .do-panelcol {
position: initial;
}
/*子导航*/

/*.z-sub-nav li a span:before{
 content: "";
 position: absolute;
 top: 8px;
 left: 0;
 height: 20px;
 width: 1px;
 background:rgb(203,203,203);
 transition:all ease-out .3s;
 
}

.z-sub-nav li:first-child a span:before{
 opacity: 0;
}


.z-subnav-conter span{padding:10px 20px; transition: all 0.3s;font-size: 14px;color:#888;}
.z-subnav-conter span:hover{color:rgb(186, 29, 29);}*/

 /* .z-subnav-conter span:hover{background-color: #ff0000;color:white;}
 .z-subnav-conter li.active span{background-color: #ff0000;color:white;}*/
 
 
 /*新闻内页*/
.do-article-title {
	text-align: center;
}
.inline {
	border-bottom: 2px solid #eee;
	padding-bottom: 10px;
}
.do-article-title h1 {
	font-size: 30px;
}
.z-subnav-conter li ul {
	border: none;
}
.breadcrumb {
	display: none;
}
.qrcode-box {
	display: none;
}
.do-article {
	border: 0;
	padding-right: 0;
}
.do-body-content .do-col-10 {
	width: 100% !important;
}
 @media only screen and (max-width: 640px) {
.z-subnav-conter span {
	padding: 0;
}
.z-subnav.do-level .z-sub-nav > li a {
	padding: 0 10px;
}
}
/*子导航*/
.z-sub-nav li a span:before {
	content: "";
	position: absolute;
	top: 8px;
	left: 0;
	height: 20px;
	width: 1px;
	background: rgb(203,203,203);
	transition: all ease-out .3s;
}
.z-sub-nav li:first-child a span:before {
	opacity: 0;
}
.z-subnav-conter span {
	padding: 10px 20px;
	transition: all 0.3s;
	/*font-size: 14px;*/
	color: #555;
}
.z-subnav-conter span:hover {
	background-color: rgb(186, 29, 29);
	color: white;
}
.z-subnav-conter li.active span {
	background-color: rgb(186, 29, 29);
	color: white;
}
 @media only screen and (max-width: 640px) {
.z-subnav-conter span {
	padding: 10px 19px;
}
.z-sub-nav li a span:before {
	background: none;
}
}
/*nav*/

.do-header .z-nav-container li > ul:not(:empty ) {
	width: 317px;
	opacity: 0;
	left: -90px;
	transform: scale(0.8);
	-webkit-box-shadow: 0 8px 20px 0 rgba(0, 0, 0, .15);
	box-shadow: 0 8px 20px 0 rgba(0, 0, 0, .15);
	transition: all 1s;
	max-height: 0;
	-webkit-transition-timing-function: cubic-bezier(.075, .82, .165, 1);
	transition-timing-function: cubic-bezier(.075, .82, .165, 1);
	overflow: hidden;
}
.do-header .z-nav-container li:hover > ul {
	opacity: 1;
	max-height: 100vh;
	padding: 50px 0;
	/*top: 57px;*/
 /*width:100%!important;*/
	-webkit-transform: scale(1);
	transform: scale(1);/*-webkit-transition-duration: .1s;*/
 /*transition-duration: .1s;*/
 /*-webkit-transition-timing-function: cubic-bezier(.075, .82, .165, 1);*/
 /*transition-timing-function: cubic-bezier(.075, .82, .165, 1);*/
}
.do-header .z-nav-container li ul li {
	height: 36px !important;
	line-height: 36px !important;
	text-align: center;
}
.breadcrumb {
	padding: 0 40px!important;
}
</style>
 <script type="text/javascript">
 var StaticUrl = '//v1-ab.cdn-static.cn/';
 var sUserAgent= navigator.userAgent.toLowerCase();
 var bIsIpad= sUserAgent.match(/ipad/i) == "ipad";
 var bIsIphoneOs= sUserAgent.match(/iphone os/i) == "iphone os";
 var bIsMidp= sUserAgent.match(/midp/i) == "midp";
 var bIsUc7= sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
 var bIsUc= sUserAgent.match(/ucweb/i) == "ucweb";
 var bIsAndroid= sUserAgent.match(/android/i) == "android";
 var bIsCE= sUserAgent.match(/windows ce/i) == "windows ce";
 var bIsWM= sUserAgent.match(/windows mobile/i) == "windows mobile";
 
 var browser=navigator.appName;
 var b_version=navigator.appVersion;
 var version=b_version.split(";");
 var _vm = {};
 var trim_Version= version[1] ? version[1].replace(/[ ]/g,"") : "";
 var isIe = {
 ie6:browser=="Microsoft Internet Explorer" && trim_Version=="MSIE6.0",
 ie7:browser=="Microsoft Internet Explorer" && trim_Version=="MSIE7.0",
 ie8:browser=="Microsoft Internet Explorer" && trim_Version=="MSIE8.0",
 ie9:browser=="Microsoft Internet Explorer" && trim_Version=="MSIE9.0"
 }

 function isWeiXin(){
 var ua = window.navigator.userAgent.toLowerCase();
 if(ua.match(/MicroMessenger/i) == 'micromessenger'){
 return true;
 }else{
 return false;
 }
 }
 
 var version = {'css':'202031911342','js' :'2021519103916'};
 
 
 function setCookie(c_name,value,expiredays)
 {
 var exdate=new Date()
 exdate.setDate(exdate.getDate()+expiredays)
 document.cookie=c_name+ "=" +escape(value)+";path=/"+((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
 }

 setCookie("time_offset", -new Date().getTimezoneOffset()/60);
</script><script src="static/js/jquery.min.js"></script>
<link rel="shortcut icon" type="image/ico" href="">
<link rel="stylesheet" href="static/css/style1.css">
<style>
 #area_932104_0 > .do-area-bg .bgcolor,#area_932104_0 .fp-tableCell > .do-area-bg .bgcolor { background-color:rgb(0, 114, 194); }#area_932104_1 .do-area-bg-conter { }#area_932104_1 .do-row-one,#area_932104_1 .do-element-text { }#area_932104_1 .do-area-bg-conter:before { }#area_932104_2 .do-area-bg-conter { }#area_932104_2 .do-row-one,#area_932104_2 .do-element-text { }#area_932104_2 .do-area-bg-conter:before { }#area_932104_3 .do-area-bg-conter { }#area_932104_3 .do-row-one,#area_932104_3 .do-element-text { }#area_932104_3 .do-area-bg-conter:before { }
 #footer_932104_0 > .do-area-bg .bgcolor,#footer_932104_0 .fp-tableCell > .do-area-bg .bgcolor { background-color:rgb(0, 119, 196); }
 </style>
<script>
 (function(){
 var obj = (document.getElementsByTagName('head')[0]||body),
 js = null;
 if(location.search=="?debug=true"){
 js = document.createElement('script');
 js.type='text/javascript';
 js.onload = function(){
 new VConsole();
 };
 js.onerror = function(e){
 alert("vonsole.js load error,err:" + e);
 };
 js.src = "//v1-ab.cdn-static.cn/editor/js/vconsole.min.js";
 obj.appendChild(js);
 }
 })();

 var jsVersion = '2021519103916',
 cssVersion = '202031911342';
 </script>
 </head>
 <body do-page-width="1" class="fr-element fr-view do-page-932104 do-kf-phoneBottom do-kf-icon-box" do-phone-nav="do-drop-full" do-phonenav-slip-direction="left-to-right" do-phonenav-btnalign="do-navBtn-right">
 <div style="display: none"><img src="static/picture/57939_knlcldz4.png"></div>
 <div class="do-nav-mwp do-nav-phone">
   <input type="checkbox" id="do-m-menustate" class="do-m-menustate">
   <div class="do-nav-m">
     <div class="do-nav-m-title animate">
       <div class="do-site-name">
         <h3><a href="javascript:;"><img class="animate" src="static/picture/57939_knlcldz41.png" alt="四川凯聚鑫建设工程有限公司"></a></h3>
       </div>
       <div class="do-m-menustate do-btn-line do-nav-btn">
         <label class="do-m-menu-btn" for="do-m-menustate"><span></span><span></span><span></span></label>
       </div>
     </div>
     <div class="do-phoneNav-overlay"></div>
     <div class="do-nav-m-bar animate">
       <ul class="do-nav-m-ul clearfix">
         <li class="nav930803" data-id="930803"><a href="javascript:;"><span>首页</span></a></li>
         <li class="nav932104 active" data-id="932104"><a href=""><span>基坑护栏</span></a>
           <input type="checkbox" id="inputNavSub932104" class="do-m-menustate do-m-sub">
           <label for="inputNavSub932104" class="icon-isSub"></label>
           <ul class="z-nav-sub">
             <li class="nav932105" data-id="932105"><a href="javascript:;"><span>定型化防护栏</span></a></li>
             <li class="nav932155" data-id="932155"><a href="javascript:;"><span>施工防护栏</span></a></li>
             <li class="nav932157" data-id="932157"><a href="javascript:;"><span>标准化防护栏</span></a></li>
             <li class="nav932161" data-id="932161"><a href="javascript:;"><span>基坑防护网</span></a></li>
             <li class="nav932167" data-id="932167"><a href="javascript:;"><span>电梯防护门</span></a></li>
           </ul>
         </li>
         <li class="nav932170" data-id="932170"><a href="javascript:;"><span>锌钢护栏</span></a></li>
         <li class="nav932173" data-id="932173"><a href="javascript:;"><span>护栏网</span></a>
           <input type="checkbox" id="inputNavSub932173" class="do-m-menustate do-m-sub">
           <label for="inputNavSub932173" class="icon-isSub"></label>
           <ul class="z-nav-sub">
             <li class="nav932238" data-id="932238"><a href="javascript:;"><span>球场围栏</span></a></li>
             <li class="nav932240" data-id="932240"><a href="javascript:;"><span>机场护栏网</span></a></li>
             <li class="nav932176" data-id="932176"><a href="javascript:;"><span>车间隔离网</span></a></li>
             <li class="nav932177" data-id="932177"><a href="javascript:;"><span>防盗网/防盗刺网</span></a></li>
             <li class="nav932178" data-id="932178"><a href="javascript:;"><span>绿化勾花网</span></a></li>
             <li class="nav932179" data-id="932179"><a href="javascript:;"><span>边框护栏网</span></a></li>
             <li class="nav932180" data-id="932180"><a href="javascript:;"><span>铁路护栏网</span></a></li>
           </ul>
         </li>
         <li class="nav932249" data-id="932249"><a href="javascript:;"><span>边坡防护网</span></a>
           <input type="checkbox" id="inputNavSub932249" class="do-m-menustate do-m-sub">
           <label for="inputNavSub932249" class="icon-isSub"></label>
           <ul class="z-nav-sub">
             <li class="nav932250" data-id="932250"><a href="javascript:;"><span>边坡绿化网</span></a></li>
             <li class="nav932251" data-id="932251"><a href="javascript:;"><span>钛克网</span></a></li>
             <li class="nav932252" data-id="932252"><a href="javascript:;"><span>被动网</span></a></li>
             <li class="nav932253" data-id="932253"><a href="javascript:;"><span>主动网</span></a></li>
             <li class="nav932254" data-id="932254"><a href="javascript:;"><span>GPS2主动网</span></a></li>
             <li class="nav932255" data-id="932255"><a href="javascript:;"><span>sns柔性网</span></a></li>
           </ul>
         </li>
         <li class="nav930832" data-id="930832"><a href="javascript:;"><span>道路护栏</span></a>
           <input type="checkbox" id="inputNavSub930832" class="do-m-menustate do-m-sub">
           <label for="inputNavSub930832" class="icon-isSub"></label>
           <ul class="z-nav-sub">
             <li class="nav932241" data-id="932241"><a href="javascript:;"><span>桥梁护栏</span></a></li>
             <li class="nav932242" data-id="932242"><a href="javascript:;"><span>道路隔离护栏</span></a></li>
             <li class="nav933862" data-id="933862"><a href="javascript:;"><span>二代隔离护栏</span></a></li>
             <li class="nav932243" data-id="932243"><a href="javascript:;"><span>防撞护栏</span></a></li>
             <li class="nav932244" data-id="932244"><a href="javascript:;"><span>市政护栏</span></a></li>
             <li class="nav932245" data-id="932245"><a href="javascript:;"><span>京式护栏</span></a></li>
             <li class="nav932247" data-id="932247"><a href="javascript:;"><span>防眩目护栏</span></a></li>
             <li class="nav932248" data-id="932248"><a href="javascript:;"><span>广告护栏板</span></a></li>
           </ul>
         </li>
         <li class="nav933163" data-id="933163"><a href="javascript:;"><span>产品中心</span></a>
           <input type="checkbox" id="inputNavSub933163" class="do-m-menustate do-m-sub">
           <label for="inputNavSub933163" class="icon-isSub"></label>
           <ul class="z-nav-sub">
             <li class="nav931931" data-id="931931"><a href="javascript:;"><span>建筑网片</span></a></li>
             <li class="nav933876" data-id="933876"><a href="javascript:;"><span>钢筋网片</span></a></li>
             <li class="nav933161" data-id="933161"><a href="javascript:;"><span>石笼网</span></a></li>
             <li class="nav933162" data-id="933162"><a href="javascript:;"><span>钢丝绳</span></a></li>
             <li class="nav934078" data-id="934078"><a href="javascript:;"><span>钢格板</span></a></li>
             <li class="nav934086" data-id="934086"><a href="javascript:;"><span>爬架网</span></a></li>
             <li class="nav933863" data-id="933863"><a href="javascript:;"><span>楼梯扶手</span></a></li>
             <li class="nav933874" data-id="933874"><a href="javascript:;"><span>阳台护栏</span></a></li>
           </ul>
         </li>
         <li class="nav933125" data-id="933125"><a href="javascript:;"><span>厂家风采</span></a></li>
         <li class="nav931933" data-id="931933"><a href="javascript:;"><span>工程案例</span></a></li>
         <li class="nav931934" data-id="931934"><a href="javascript:;"><span>新闻动态</span></a></li>
         <li class="nav931935" data-id="931935"><a href="javascript:;"><span>联系我们</span></a></li>
       </ul>
       <div class="do-site-name animate do-nav-m-bar-name">
         <h3></h3>
         <h3><a href="javascript:;"><img class="animate"></a></h3>
       </div>
     </div>
   </div>
 </div>
 <div class="do-adrift">
   <div class="do-popwximg" style="display:none">
     <div class="do-middle">
       <div class="do-middle-center"><img src="static/picture/62777_kpxex0mr.jpg" width="160">
         <p class="wxphone">长按二维码关注微信加好友</p>
       </div>
     </div>
     <i class="icon-close do-close"></i></div>
   <input type="checkbox" id="do-online-service" class="do-hide">
   <div class="do-online-service">
     <label for="do-online-service" class="do-online-service-btn icon-bubbles do-open do-bg-blue1"></label>
     <div class="do-box">
       <div class="do-box-title do-bg-blue1">在线咨询
         <label for="do-online-service" class="icon-close do-close"></label>
       </div>
       <div class="do-box-con">
         <div class="do-box-item qq"><a href="javascript:;" target="_blank" class="on" title="" id="bizQQ_WPA"><i class="icon-qq"></i><span>532178620</span><em>在线QQ</em></a></div>
         <div class="do-box-item mail"><a href="mailto:532178620@qq.com" title="" class="on"><i class="icon-mail"></i><span>532178620@qq.com</span></a></div>
         <div class="do-box-item tel">
           <h6><i class="icon-phone"></i> 电话</h6>
           <h4><a href="tel:15388189989"><i class="icon-phone"></i><span>15388189989</span><em>拨打</em></a></h4>
         </div>
         <div class="do-box-item sms"><a href="javascript:;"><i class="icon-mail"></i><em>发送短信</em></a></div>
         <div class="do-box-item qr"><a href="javascript:;" class="weixinBtn phoneOff"><i class="icon-weixin"></i><em>微信</em></a>
           <div class="wximg phoneNone"><img src="static/picture/62777_kpxex0mr.jpg" width="100%">
             <p class="wxpc">微信扫一扫</p>
             <p class="wxphone">长按二维码关注微信加好友</p>
           </div>
         </div>
       </div>
     </div>
   </div>
   <div class="do-gotop" title="返回顶部"><i class="icon-to-top"></i></div>
 </div>
 <div class="do-container animate">
 <div class=" do-section fp-auto-height do-header" do-header-fixed="" data-fullname="TOP">
   <div class="do-area do-area-full" id="header_932104_0">
     <div class="do-area-bg">
       <div class="do-area-bg-conter">
         <div class="bgcolor"></div>
       </div>
     </div>
     <div id="header_0" class="do-row do-row-one">
       <div class="do-row

 ">
         <div class="do-col-12 do-H-c-76-77" id='H-c-76-77'>
           <div class="do-panelcol">
             <div class="do-block
 
 do-rows">
               <div class="do-row

">
                 <div class="do-col-12 do-H-c-76-77-78-81" id='H-c-76-77-78-81'>
                   <div class="do-panelcol">
                     <div class="do-block
 
 do-rows">
                       <div class="do-row

 huzi-top">
                         <div class="do-col-6 do-H-c-0-1-2-3-4-156" id='H-c-0-1-2-3-4-156'>
                           <div class="do-panelcol">
                             <div class="do-block
 
 
 
 
 do-logo do-1l6yme">
                               <div do-logo="" class="do-logo">
                                 <div class="z-logo align-center size16"><a href="javascript:;" title=""><img src="static/picture/57939_knlcldz42.png" alt=""></a></div>
                               </div>
                             </div>
                           </div>
                         </div>
                         <div class="do-col-3 do-H-c-0-1-2-3-4-127" id='H-c-0-1-2-3-4-127'>
                           <div class="do-panelcol">
                             <div class="do-block
 
 
 
 
 do-text do-1l3ho3">
                               <div class="do-text-1l3ho3">
                                 <div class="do-element-text do-element-general">
                                   <div class="do-element-text-content do-html">
                                     <div class="do-html-content">
                                       <p style="text-align: center; line-height: 1.2;"><strong><span style="font-family: &quot;Microsoft YaHei&quot;, 微软雅黑, MicrosoftJhengHei, 华文细黑, STHeiti, MingLiu; font-size: 30px; color: rgb(0, 114, 194);">专注品质，保障服务</span></strong></p>
                                       <p style="text-align: center; line-height: 1.2;"><span style="font-size: 18px;">愿我的服务和质量与您随时相伴</span></p>
                                     </div>
                                   </div>
                                 </div>
                               </div>
                             </div>
                           </div>
                         </div>
                         <div class="do-col-1 do-H-c-0-1-2-3-4-144" id='H-c-0-1-2-3-4-144'>
                           <div class="do-panelcol">
                             <div class="do-block
 
 
 
 
 do-space do-1l6ymi">
                               <div class="do-element-space pc" style="padding-top:8.664259927797833%;"></div>
                               <div class="do-element-space phone" style="padding-top:5%;"></div>
                             </div>
                             <div class="do-block
 
 
 
 
 do-image do-1l6ymg">
                               <div class="do-element-image do-element-media


">
                                 <div class="do-element-image-content do-html" style="padding-top:53.57142857142857%;">
                                   <div class="do-image-href do-img-animation sizeimg3 ">
                                     <div class="do-middle">
                                       <div class="do-middle-center"><img class="scrollLoading" data-src="//v1.cdn-static.cn/2021/3/26/57939_kmq31jv8.jpg?imageView2/2/w/224/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" alt=""></div>
                                     </div>
                                   </div>
                                 </div>
                               </div>
                             </div>
                             <div class="do-block
 
 
 
 
 do-space do-1l6ymh">
                               <div class="do-element-space pc" style="padding-top:9.821428571428571%;"></div>
                               <div class="do-element-space phone" style="padding-top:5%;"></div>
                             </div>
                           </div>
                         </div>
                         <div class="do-col-2 do-H-c-0-1-2-3-4-137" id='H-c-0-1-2-3-4-137'>
                           <div class="do-panelcol">
                             <div class="do-block
 
 
 
 
 do-text do-1l3ho1">
                               <div class="do-text-1l3ho1">
                                 <div class="do-element-text do-element-general">
                                   <div class="do-element-text-content do-html">
                                     <div class="do-html-content">
                                       <p><span style="font-size: 28px;"><strong>18980777678</strong></span></p>
                                     </div>
                                   </div>
                                 </div>
                               </div>
                             </div>
                           </div>
                         </div>
                       </div>
                     </div>
                     <div class="do-block
 
 
 
 
 do-nav do-1l1buz">
                       <div class="z-nav align-center">
                         <div class="z-nav-bar">
                           <div class="z-nav-container">
                             <ul class="z-nav-conter clearfix">
                               <li class="nav930803" data-id="930803"><a href="javascript:;"><span>首页</span></a></li>
                               <li class="nav932104 active" data-id="932104"><a href=""><span>基坑护栏</span></a>
                                 <input type="checkbox" id="inputNavSub932104" class="do-m-menustate do-m-sub">
                                 <label for="inputNavSub932104" class="icon-isSub"></label>
                                 <ul class="z-nav-sub">
                                   <li class="nav932105" data-id="932105"><a href="javascript:;"><span>定型化防护栏</span></a></li>
                                   <li class="nav932155" data-id="932155"><a href="javascript:;"><span>施工防护栏</span></a></li>
                                   <li class="nav932157" data-id="932157"><a href="javascript:;"><span>标准化防护栏</span></a></li>
                                   <li class="nav932161" data-id="932161"><a href="javascript:;"><span>基坑防护网</span></a></li>
                                   <li class="nav932167" data-id="932167"><a href="javascript:;"><span>电梯防护门</span></a></li>
                                 </ul>
                               </li>
                               <li class="nav932170" data-id="932170"><a href="javascript:;"><span>锌钢护栏</span></a></li>
                               <li class="nav932173" data-id="932173"><a href="javascript:;"><span>护栏网</span></a>
                                 <input type="checkbox" id="inputNavSub932173" class="do-m-menustate do-m-sub">
                                 <label for="inputNavSub932173" class="icon-isSub"></label>
                                 <ul class="z-nav-sub">
                                   <li class="nav932238" data-id="932238"><a href="javascript:;"><span>球场围栏</span></a></li>
                                   <li class="nav932240" data-id="932240"><a href="javascript:;"><span>机场护栏网</span></a></li>
                                   <li class="nav932176" data-id="932176"><a href="javascript:;"><span>车间隔离网</span></a></li>
                                   <li class="nav932177" data-id="932177"><a href="javascript:;"><span>防盗网/防盗刺网</span></a></li>
                                   <li class="nav932178" data-id="932178"><a href="javascript:;"><span>绿化勾花网</span></a></li>
                                   <li class="nav932179" data-id="932179"><a href="javascript:;"><span>边框护栏网</span></a></li>
                                   <li class="nav932180" data-id="932180"><a href="javascript:;"><span>铁路护栏网</span></a></li>
                                 </ul>
                               </li>
                               <li class="nav932249" data-id="932249"><a href="javascript:;"><span>边坡防护网</span></a>
                                 <input type="checkbox" id="inputNavSub932249" class="do-m-menustate do-m-sub">
                                 <label for="inputNavSub932249" class="icon-isSub"></label>
                                 <ul class="z-nav-sub">
                                   <li class="nav932250" data-id="932250"><a href="javascript:;"><span>边坡绿化网</span></a></li>
                                   <li class="nav932251" data-id="932251"><a href="javascript:;"><span>钛克网</span></a></li>
                                   <li class="nav932252" data-id="932252"><a href="javascript:;"><span>被动网</span></a></li>
                                   <li class="nav932253" data-id="932253"><a href="javascript:;"><span>主动网</span></a></li>
                                   <li class="nav932254" data-id="932254"><a href="javascript:;"><span>GPS2主动网</span></a></li>
                                   <li class="nav932255" data-id="932255"><a href="javascript:;"><span>sns柔性网</span></a></li>
                                 </ul>
                               </li>
                               <li class="nav930832" data-id="930832"><a href="javascript:;"><span>道路护栏</span></a>
                                 <input type="checkbox" id="inputNavSub930832" class="do-m-menustate do-m-sub">
                                 <label for="inputNavSub930832" class="icon-isSub"></label>
                                 <ul class="z-nav-sub">
                                   <li class="nav932241" data-id="932241"><a href="javascript:;"><span>桥梁护栏</span></a></li>
                                   <li class="nav932242" data-id="932242"><a href="javascript:;"><span>道路隔离护栏</span></a></li>
                                   <li class="nav933862" data-id="933862"><a href="javascript:;"><span>二代隔离护栏</span></a></li>
                                   <li class="nav932243" data-id="932243"><a href="javascript:;"><span>防撞护栏</span></a></li>
                                   <li class="nav932244" data-id="932244"><a href="javascript:;"><span>市政护栏</span></a></li>
                                   <li class="nav932245" data-id="932245"><a href="javascript:;"><span>京式护栏</span></a></li>
                                   <li class="nav932247" data-id="932247"><a href="javascript:;"><span>防眩目护栏</span></a></li>
                                   <li class="nav932248" data-id="932248"><a href="javascript:;"><span>广告护栏板</span></a></li>
                                 </ul>
                               </li>
                               <li class="nav933163" data-id="933163"><a href="javascript:;"><span>产品中心</span></a>
                                 <input type="checkbox" id="inputNavSub933163" class="do-m-menustate do-m-sub">
                                 <label for="inputNavSub933163" class="icon-isSub"></label>
                                 <ul class="z-nav-sub">
                                   <li class="nav931931" data-id="931931"><a href="javascript:;"><span>建筑网片</span></a></li>
                                   <li class="nav933876" data-id="933876"><a href="javascript:;"><span>钢筋网片</span></a></li>
                                   <li class="nav933161" data-id="933161"><a href="javascript:;"><span>石笼网</span></a></li>
                                   <li class="nav933162" data-id="933162"><a href="javascript:;"><span>钢丝绳</span></a></li>
                                   <li class="nav934078" data-id="934078"><a href="javascript:;"><span>钢格板</span></a></li>
                                   <li class="nav934086" data-id="934086"><a href="javascript:;"><span>爬架网</span></a></li>
                                   <li class="nav933863" data-id="933863"><a href="javascript:;"><span>楼梯扶手</span></a></li>
                                   <li class="nav933874" data-id="933874"><a href="javascript:;"><span>阳台护栏</span></a></li>
                                 </ul>
                               </li>
                               <li class="nav933125" data-id="933125"><a href="javascript:;"><span>厂家风采</span></a></li>
                               <li class="nav931933" data-id="931933"><a href="javascript:;"><span>工程案例</span></a></li>
                               <li class="nav931934" data-id="931934"><a href="javascript:;"><span>新闻动态</span></a></li>
                               <li class="nav931935" data-id="931935"><a href="javascript:;"><span>联系我们</span></a></li>
                             </ul>
                           </div>
                         </div>
                         <div class="z-nav-btn"><span class="line-1"></span><span class="line-2"></span><span class="line-3"></span></div>
                       </div>
                       <style>
 .z-nav { background-color:rgb(0, 114, 194);text-align:center; }.z-nav-conter > li.active > a,.z-nav-conter > li:hover > a { background-color:rgba(255, 255, 255, 0.21);color:rgb(255, 255, 255); }.lt-ie9 .z-nav-conter > li.active > a,.z-nav-conter > li:hover > a { filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#33ffffff,endColorstr=#33ffffff) }.z-nav-conter > li:hover > a { background-color:rgb(255, 255, 255);color:rgb(0, 114, 194); }.z-nav-conter > li > a { color:rgb(255, 255, 255);font-size:16px;line-height:2.03em; }
</style>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
 <div class="do-section fp-auto-height do-banner" data-fullname="BANNER">
   <div class="do-area do-area-full" id="banner_932104_0">
     <div class="do-area-bg ">
       <div class="do-area-bg-conter">
         <div class="bgcolor"></div>
       </div>
     </div>
     <div id="banner_0" class="do-row do-row-one ">
       <div class="do-row

 ">
         <div class="do-col-12 do-B-c-67-68" id='B-c-67-68'>
           <div class="do-panelcol">
             <div class="do-block
 
 
 
 
 do-slide do-1l1ddk">
               <div class="do-element-swiper do-element-slide

" style="padding-top:30.560271646859082%;">
                 <div class="do-element-swiper-content swiper-container" data-effect="slide" id="slide_1l1ddk">
                   <div class="swiper-wrapper">
                     <div class="swiper-slide">
                       <div class="do-element-slide-img">
                         <div class="do-slide-bg">
                           <div class="do-slide-bg-conter bgimg" title="" style="background-image:url(static/image/57939_kmkav6b3.jpg);

 

 "></div>
                         </div>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
 <div class="do-body">
 <div class="do-section do-area" id="area_932104_0" data-fullname="">
   <div class="do-area-bg ">
     <div class="do-area-bg-conter">
       <div class="bgcolor"></div>
     </div>
   </div>
   <div id="area_0" class="do-row do-row-one ">
     <div class="do-row

 ">
       <div class="do-col-12 do-D-c-100-101" id='D-c-100-101'>
         <div class="do-panelcol">
           <div class="do-block
 
 
 
 
 do-space do-1l1ddl">
             <div class="do-element-space pc" style="padding-top:1.6666666666666667%;"></div>
             <div class="do-element-space phone" style="padding-top:5%;"></div>
           </div>
           <div class="do-block
 
 
 
 
 
 
 do-text do-1l1ddh">
             <div class="do-text-1l1ddh">
               <div class="do-element-text do-element-general">
                 <div class="do-element-text-content do-html">
                   <div class="do-html-content">
                     <p style="text-align: center; line-height: 1; letter-spacing: 5px;"><span style="font-size: 30px; color: rgb(255, 255, 255);"><strong>产品中心</strong>·基坑护栏</span></p>
                   </div>
                 </div>
               </div>
             </div>
           </div>
           <div class="do-block
 
 
 
 
 do-title do-1l1ddg">
             <div class="do-element-title 
">
               <div class="do-element-title-content">
                 <div class="do-middle">
                   <div class="do-middle-center align-center">
                     <div class="title-name">
                       <div class="title-name-conter do-html-content">
                         <hr>
                         <p><span style="font-size: 18px; color: rgb(255, 255, 255);">PRODUCT CENTER</span></p>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
 <div class="do-section do-area" id="area_932104_1" data-fullname="">
   <div class="do-area-bg ">
     <div class="do-area-bg-conter">
       <div class="bgcolor"></div>
     </div>
   </div>
   <div id="area_1" class="do-row do-row-one ">
     <div class="do-row

 ">
       <div class="do-col-12 do-D-c-41-42" id='D-c-41-42'>
         <div class="do-panelcol">
           <div class="do-block
 
 
 
 
 do-text do-1l746l">
             <div class="do-text-1l746l">
               <div class="do-element-text do-element-general">
                 <div class="do-element-text-content do-html">
                   <div class="do-html-content">
                     <p>快速通道： <a href="javascript:;">首页</a> / 基坑护栏</p>
                   </div>
                 </div>
               </div>
             </div>
           </div>
           <div class="do-block
 
 
 
 
 do-space do-1l30jy">
             <div class="do-element-space pc" style="padding-top:3.3333333333333335%;"></div>
             <div class="do-element-space phone" style="padding-top:16.400000000000002%;"></div>
           </div>
           <div class="do-block
 
 
 
 
 do-list do-1l8d71">
             <div class="do-element-media x
 num9 phoneRows3
 ">
               <div class="do-element-media-content md " id="swiper_1l8d71" data-rows="9" data-phonerows="3" data-initialslide="0" data-slidespercolumn="1">
                 <ul class="do-element-media-ul x do-content-grid ">
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 active
 
 pgid-932104
 " data-wow-delay=".0s"><a href="">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>基坑护栏</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932170
 " data-wow-delay=".1s"><a href="javascript:;">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>锌钢护栏</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-930832
 " data-wow-delay=".2s"><a href="javascript:;">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>道路护栏</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932244
 " data-wow-delay=".3s"><a href="javascript:;">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>市政护栏</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-931931
 " data-wow-delay=".4s"><a href="javascript:;">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>建筑网片</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-933876
 " data-wow-delay=".5s"><a href="javascript:;">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>钢筋网片</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932173
 " data-wow-delay=".6s"><a href="javascript:;">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>护栏网</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932253
 " data-wow-delay=".7s"><a href="javascript:;">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>主动网</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                   <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-933161
 " data-wow-delay=".8s"><a href="javascript:;">
                     <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                         <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                             <div class="do-html-content title">
                              <p>石笼网</p>
                            </div>
                           </div>
                        </div>
                       </div>
                    </div>
                     </a></li>
                 </ul>
               </div>
             </div>
             <style>
.do-1l8d71 .do-element-media-conter { padding:5px; }.do-1l8d71 .do-title,.do-1l8d71 .do-caption-overlay .do-title,.do-1l8d71 .do-caption-overlay-hover .do-title,.do-1l8d71 .do-caption-overlay-hover-cover .do-title { background-color:rgb(0, 119, 196); }.do-1l8d71 .do-middle-center img { width:100%; }.do-1l8d71 .do-title .title { font-size:19px;line-height:1.70em;text-align:center;color:rgb(255, 255, 255); }.do-1l8d71 .do-element-media-conter { border:1px dotted rgb(0,119,196); }
</style>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
 <div class="do-section do-area" id="area_932104_2" data-fullname="">
 <div class="do-area-bg ">
   <div class="do-area-bg-conter">
     <div class="bgcolor"></div>
   </div>
 </div>
 <div id="area_2" class="do-row do-row-one ">
 <div class="do-row

 ">
 <div class="do-col-3 do-D-c-24-88" id='D-c-24-88'>
 <div class="do-panelcol">
 <div class="do-block
 
 
 
 
 do-space do-1l6t3s">
   <div class="do-element-space pc" style="padding-top:11.66077738515901%;"></div>
   <div class="do-element-space phone" style="padding-top:5%;"></div>
 </div>
 <div class="do-block
 
 
 
 
 do-code do-1l97xp">
 <div class="do-element-code">
 <div class="do-element-code-content">
 <!DOCTYPE html>
 <html>
 <head>
 <meta charset="UTF-8">
 <title></title>
 <style>

@media screen and (max-width: 500px){
 .left-pc{display:none;}
}
 .left-pc{min-height:60px
 ;background:#016cb2;float:left;width:100%;color:#fff; margin-bottom:10px;}
 .left-pc .pc-si{height:80px;line-height:80px;text-align:center;color:#fff;font-size:24px;background:#0081d5}
 .left-pc a{ display:block;color:#fff;}
 .left-pc .pc-box{display:block; background:#006bb0;text-align:center;}
 .left-pc .pc-box dt{border-bottom:1px dotted #58affe;width:100%;height:55px;font-size:16px;line-height:55px;float:left}
 .left-pc .pc-box dd{border-bottom:1px dotted #58afff;width:50%;height:38px;line-height:38px;float:left;background:#0077c4}
 .left-pc .pc-box dd a{border-left:1px dotted #58afff;}
 .left-pc .pc-box dd:hover{background:#034a78}
 .left-pc .pc-box dd a{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
 .left-pc .pc-box dd a:after{content:"·";display:block;height:0;visibility:hidden;}

</style>
 </head>
 <body>
 <div class="left-pc">
   <div class="pc-si"><a>产品系列 <i class="fa fa-list-ul"></i></a></div>
   <dl class="pc-box">
     <dt><a href="javascript:;" title="网片系列">网片系列</a></dt>
     <dd><a href="javascript:;">建筑网片</a></dd>
     <dd><a href="javascript:;">钢筋网片</a></dd>
     <dt><a href="javascript:;" title="基坑护栏">基坑护栏</a></dt>
     <dd><a href="javascript:;" title="基坑护栏">基坑护栏</a></dd>
     <dd><a href="javascript:;" title="定型化防护栏">定型化防护栏</a></dd>
     <dd><a href="javascript:;" title="施工防护栏">施工防护栏</a></dd>
     <dd><a href="javascript:;" title="标准化防护栏">标准化防护栏</a></dd>
     <dd><a href="javascript:;" title="基坑防护网">基坑防护网</a></dd>
     <dd><a href="javascript:;" title="电梯防护门">电梯防护门</a></dd>
     <dt><a href="javascript:;" title="护栏网系列">护栏网系列</a></dt>
     <dd><a href="javascript:;" title="锌钢围栏">锌钢护栏</a></dd>
     <dd><a href="javascript:;" title="球场围栏">球场围栏</a></dd>
     <dd><a href="javascript:;" title="机场护栏网">机场护栏网</a></dd>
     <dd><a href="javascript:;" title="车间隔离网">车间隔离网</a></dd>
     <dd><a href="javascript:;" title="防盗网/防盗网刺">防盗网/防盗网刺</a></dd>
     <dd><a href="javascript:;" title="绿化勾花网">绿化勾花网</a></dd>
     <dd><a href="javascript:;" title="边框护栏网">边框护栏网</a></dd>
     <dd><a href="javascript:;" title="铁路护栏网">铁路护栏网</a></dd>
     <dt><a href="javascript:;" title="边坡防护网">边坡防护网</a></dt>
     <dd><a href="javascript:;" title="边坡绿化网">边坡绿化网</a></dd>
     <dd><a href="javascript:;" title="钛克网">钛克网</a></dd>
     <dd><a href="javascript:;" title="被动网">被动网</a></dd>
     <dd><a href="javascript:;" title="主动网">主动网</a></dd>
     <dd><a href="javascript:;" title="GPS2主动网">GPS2主动网</a></dd>
     <dd><a href="javascript:;" title="sns柔性网">sns柔性网</a></dd>
     <dt><a href="javascript:;">道路护栏</a></dt>
     <dd><a href="javascript:;">桥梁护栏</a></dd>
     <dd><a href="javascript:;">二代隔离护栏</a></dd>
     <dd><a href="javascript:;">道路隔离护栏</a></dd>
     <dd><a href="javascript:;">防撞护栏</a></dd>
     <dd><a href="javascript:;">市政护栏</a></dd>
     <dd><a href="javascript:;">京式护栏</a></dd>
     <dd><a href="javascript:;">防眩目护栏</a></dd>
     <dd><a href="javascript:;">广告护栏板</a></dd>
     <dt><a href="javascript:;">石笼网系列</a></dt>
     <dd><a href="javascript:;">石笼网</a></dd>
     <dd><a href="javascript:;">格宾网</a></dd>
     <dd><a href="javascript:;">石笼网箱</a></dd>
     <dd><a href="javascript:;">雷诺护垫</a></dd>
     <dt><a href="javascript:;">其他系列</a></dt>
     <dd><a href="javascript:;">钢丝绳</a></dd>
     <dd><a href="javascript:;">钢格板</a></dd>
     <dd><a href="javascript:;">爬架网</a></dd>
     <dd><a href="javascript:;">楼梯扶手</a></dd>
     <dd><a href="javascript:;">阳台护栏</a></dd>
     <div class="cl"></div>
   </dl>
 </div>
 <a href="https://smalltool.github.io/" style="display:none;">快速仿站</a>
</body>
</html>
</div>
</div>
</div>
</div>
</div>
<div class="do-col-9 do-D-c-41-42" id='D-c-41-42'>
  <div class="do-panelcol">
    <div class="do-block
 
 
 
 
 do-space do-1l30jw">
      <div class="do-element-space pc" style="padding-top:2.4166666666666665%;"></div>
      <div class="do-element-space phone" style="padding-top:5%;"></div>
    </div>
    <div class="do-block
 
 
 
 
 do-text do-1l1dce">
      <div class="do-text-1l1dce">
        <div class="do-element-text do-element-general">
          <div class="do-element-text-content do-html">
            <div class="do-html-content">
              <p><span style="font-size: 26px;"><strong>定型化防护栏</strong></span><span style="font-size: 18px;">/</span><span style="font-size: 18px; color: rgb(102, 102, 102);">SHAPED GUARDRAIL</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="do-block
 
 
 
 
 do-space do-1l1dcd">
      <div class="do-element-space pc" style="padding-top:1.9166666666666665%;"></div>
      <div class="do-element-space phone" style="padding-top:5%;"></div>
    </div>
    <div class="do-block
 
 
 
 
 do-list do-1l1dcc">
      <div class="do-element-media x
 num4 phoneRows2
 ">
        <div class="do-element-media-content md " id="swiper_1l1dcc" data-rows="4" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1">
          <ul class="do-element-media-ul x do-content-grid ">
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932105
 " data-wow-delay=".0s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk055ps.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -6.47163%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>定型化防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932105
 " data-wow-delay=".1s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk05u2h.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -18.9716%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>定型化防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932105
 " data-wow-delay=".2s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk05cev.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: -5.18041%; margin-top: 0%; width: 110.361%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>定型化防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932105
 " data-wow-delay=".3s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/26/57939_kmpym7fb.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -6.54306%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>定型化防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
          </ul>
        </div>
      </div>
      <style>
.do-1l1dcc .do-middle-center img { width:100%; }.do-1l1dcc .do-title .title { font-size:16px;line-height:0.99em;text-align:center; }
</style>
    </div>
    <div class="do-block
 
 
 
 
 do-space do-1l6t3q">
      <div class="do-element-space pc" style="padding-top:3.737259343148358%;"></div>
      <div class="do-element-space phone" style="padding-top:5%;"></div>
    </div>
    <div class="do-block
 
 
 
 
 do-text do-1l6t3r">
      <div class="do-text-1l6t3r">
        <div class="do-element-text do-element-general">
          <div class="do-element-text-content do-html">
            <div class="do-html-content">
              <p><span style="font-size: 26px;"><strong>施工防护栏</strong></span><span style="font-size: 18px;">/</span><span style="font-size: 18px;">/</span><span style="font-size: 18px; color: rgb(102, 102, 102);">SHAPED GUARDRAIL</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="do-block
 
 
 
 
 do-list do-1l6t3m">
      <div class="do-element-media x
 num4 phoneRows2
 ">
        <div class="do-element-media-content md " id="swiper_1l6t3m" data-rows="4" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1">
          <ul class="do-element-media-ul x do-content-grid ">
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932155
 " data-wow-delay=".0s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/4/7/57939_kn743j7z_406810.png?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: -5.23399%; margin-top: 0%; width: 110.468%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>施工防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932155
 " data-wow-delay=".1s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/25/57939_kmo8ism6.png?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -2.16552%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>施工防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932155
 " data-wow-delay=".2s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/4/7/57939_kn74512s_62726.png?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: -5.41872%; margin-top: 0%; width: 110.837%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>施工防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932155
 " data-wow-delay=".3s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/4/7/57939_kn7465vr_808038.png?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -6.58654%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>施工防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
          </ul>
        </div>
      </div>
      <style>
.do-1l6t3m .do-middle-center img { width:100%; }.do-1l6t3m .do-title .title { font-size:16px;line-height:0.99em;text-align:center; }
</style>
    </div>
    <div class="do-block
 
 
 
 
 do-space do-1l1dcb">
      <div class="do-element-space pc" style="padding-top:2.5833333333333335%;"></div>
      <div class="do-element-space phone" style="padding-top:5%;"></div>
    </div>
    <div class="do-block
 
 
 
 
 do-text do-1l6t3l">
      <div class="do-text-1l6t3l">
        <div class="do-element-text do-element-general">
          <div class="do-element-text-content do-html">
            <div class="do-html-content">
              <p><span style="font-size: 26px;"><strong>标准化防护栏</strong></span><span style="font-size: 18px;">/</span><span style="font-size: 18px;">/</span><span style="font-size: 18px; color: rgb(102, 102, 102);">SHAPED GUARDRAIL</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="do-block
 
 
 
 
 do-list do-1l6t3j">
      <div class="do-element-media x
 num4 phoneRows2
 ">
        <div class="do-element-media-content md " id="swiper_1l6t3j" data-rows="4" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1">
          <ul class="do-element-media-ul x do-content-grid ">
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932157
 " data-wow-delay=".0s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk0iryt.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -6.46552%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>标准化防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932157
 " data-wow-delay=".1s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk0j4an.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -6.46552%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>标准化防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932157
 " data-wow-delay=".2s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk0jbd8.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -6.46552%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>标准化防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932157
 " data-wow-delay=".3s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk0jiic.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -2.2102%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>标准化防护栏</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
          </ul>
        </div>
      </div>
      <style>
.do-1l6t3j .do-middle-center img { width:100%; }.do-1l6t3j .do-title .title { font-size:16px;line-height:0.99em;text-align:center; }
</style>
    </div>
    <div class="do-block
 
 
 
 
 do-space do-1l6t3g">
      <div class="do-element-space pc" style="padding-top:3.2842582106455263%;"></div>
      <div class="do-element-space phone" style="padding-top:5%;"></div>
    </div>
    <div class="do-block
 
 
 
 
 do-text do-1l6t3h">
      <div class="do-text-1l6t3h">
        <div class="do-element-text do-element-general">
          <div class="do-element-text-content do-html">
            <div class="do-html-content">
              <p><span style="font-size: 26px;"><strong>基坑防护网</strong></span><span style="font-size: 18px;">/FOUNDATION PIT PROTECTION NET</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="do-block
 
 
 
 
 do-list do-1l6t3d">
      <div class="do-element-media x
 num4 phoneRows2
 ">
        <div class="do-element-media-content md " id="swiper_1l6t3d" data-rows="4" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1">
          <ul class="do-element-media-ul x do-content-grid ">
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932161
 " data-wow-delay=".0s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk08oq4.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -8.96552%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>基坑防护网</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932161
 " data-wow-delay=".1s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk08w64.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -18.9655%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>基坑防护网</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932161
 " data-wow-delay=".2s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmkagn9e.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 7.00042e-15%; margin-top: -6.46552%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>基坑防护网</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932161
 " data-wow-delay=".3s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk0mc04.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -18.9655%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>基坑防护网</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
          </ul>
        </div>
      </div>
      <style>
.do-1l6t3d .do-middle-center img { width:100%; }.do-1l6t3d .do-title .title { font-size:16px;line-height:0.99em;text-align:center; }
</style>
    </div>
    <div class="do-block
 
 
 
 
 do-space do-1l6t3b">
      <div class="do-element-space pc" style="padding-top:3.737259343148358%;"></div>
      <div class="do-element-space phone" style="padding-top:5%;"></div>
    </div>
    <div class="do-block
 
 
 
 
 do-text do-1l6t3c">
      <div class="do-text-1l6t3c">
        <div class="do-element-text do-element-general">
          <div class="do-element-text-content do-html">
            <div class="do-html-content">
              <p><span style="font-size: 26px;"><strong>电梯防护门</strong></span><span style="font-size: 18px;">/ELEVATOR PROTECTIVE DOOR</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="do-block
 
 
 
 
 do-list do-1l6t39">
      <div class="do-element-media x
 num4 phoneRows2
 ">
        <div class="do-element-media-content md " id="swiper_1l6t39" data-rows="4" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1">
          <ul class="do-element-media-ul x do-content-grid ">
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932167
 " data-wow-delay=".0s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk055ps.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -6.46552%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>电梯防护门</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932167
 " data-wow-delay=".1s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk05u2h.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -18.9655%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>电梯防护门</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932167
 " data-wow-delay=".2s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/22/57939_kmk05cev.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: -5.19128%; margin-top: 0%; width: 110.383%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>电梯防护门</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
            <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932167
 " data-wow-delay=".3s"><a href="javascript:;">
              <div class="do-element-media-conter clearfix do-caption-overlay ">
                <div class="do-media-image-box o-mask">
                  <div class="do-media-image">
                    <div class="do-media-image-conter"><img class="scrollLoading" alt="" data-src="//v1.cdn-static.cn/2021/3/26/57939_kmpym7fb.jpg?imageView2/2/w/406/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" style="margin-left: 0%; margin-top: -9.35837%; width: 100%;"></div>
                  </div>
                </div>
                <div class="do-title do-html-content">
                  <div class="do-title-body">
                    <div class="do-title-content do-html-content">
                      <div class="do-html-content title">
                        <p>电梯防护门</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              </a></li>
          </ul>
        </div>
      </div>
      <style>
.do-1l6t39 .do-middle-center img { width:100%; }.do-1l6t39 .do-title .title { font-size:16px;line-height:0.99em;text-align:center; }
</style>
    </div>
  </div>
</div>
</div>
</div>
</div>
<div class="do-section do-area" id="area_932104_3" data-fullname="">
  <div class="do-area-bg ">
    <div class="do-area-bg-conter">
      <div class="bgcolor"></div>
    </div>
  </div>
  <div id="area_3" class="do-row do-row-one ">
    <div class="do-row

 ">
      <div class="do-col-12 do-D-c-64-65" id='D-c-64-65'>
        <div class="do-panelcol">
          <div class="do-block
 
 
 
 
 do-space do-1l6t38">
            <div class="do-element-space pc" style="padding-top:3.3333333333333335%;"></div>
            <div class="do-element-space phone" style="padding-top:5%;"></div>
          </div>
          <div class="do-block
 
 
 
 
 do-hr do-1l4ro1">
            <div class="do-element-line default ">
              <div class="do-element-line-content">
                <div class="do-middle">
                  <div class="do-middle-center">
                    <hr style="border-color:#444;">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="do-block
 
 
 
 
 do-list do-1l4ro0">
            <div class="do-element-media x
 num10 phoneRows2
 ">
              <div class="do-element-media-content " id="swiper_1l4ro0" data-rows="10" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1">
                <ul class="do-element-media-ul x do-content-grid ">
                  <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 " data-wow-delay=".0s">
                    <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                        <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                            <div class="do-html-content title">
                              <p><span style="font-size: 16px;">项目直通车：</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 active
 
 pgid-932104
 " data-wow-delay=".1s"><a href="">
                    <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                        <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                            <div class="do-html-content title">
                              <p>基坑护栏</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a></li>
                  <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932105
 " data-wow-delay=".2s"><a href="javascript:;">
                    <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                        <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                            <div class="do-html-content title">
                              <p>定型化防护栏</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a></li>
                  <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932155
 " data-wow-delay=".3s"><a href="javascript:;">
                    <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                        <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                            <div class="do-html-content title">
                              <p>施工防护栏</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a></li>
                  <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932157
 " data-wow-delay=".4s"><a href="javascript:;">
                    <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                        <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                            <div class="do-html-content title">
                              <p>标准化防护栏</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a></li>
                  <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932161
 " data-wow-delay=".5s"><a href="javascript:;">
                    <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                        <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                            <div class="do-html-content title">
                              <p>基坑防护网</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a></li>
                  <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932167
 " data-wow-delay=".6s"><a href="javascript:;">
                    <div class="do-element-media-conter clearfix do-caption-noimg ">
                      <div class="do-title do-html-content">
                        <div class="do-title-body">
                          <div class="do-title-content do-html-content">
                            <div class="do-html-content title">
                              <p>电梯防护门</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a></li>
                </ul>
              </div>
            </div>
            <style>
.do-1l4ro0 .do-middle-center img { width:100%; }.do-1l4ro0 .do-title .title { font-size:14px;line-height:1.50em;text-align:center; }
</style>
          </div>
          <div class="do-block
 
 
 
 
 do-space do-1l4rnz">
            <div class="do-element-space pc" style="padding-top:1.5%;"></div>
            <div class="do-element-space phone" style="padding-top:17.1%;"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<div class="do-footer">
  <div class="do-area" id="footer_932104_0">
    <div class="do-area-bg">
      <div class="do-area-bg-conter">
        <div class="bgcolor"></div>
      </div>
    </div>
    <div id="footer_0" class="do-row do-row-one">
      <div class="do-row

 ">
        <div class="do-col-12 do-D-c-47-48" id='D-c-47-48'>
          <div class="do-panelcol">
            <div class="do-block
 
 
 
 
 do-space do-1l34vc">
              <div class="do-element-space pc" style="padding-top:6.666666666666667%;"></div>
              <div class="do-element-space phone" style="padding-top:16.400000000000002%;"></div>
            </div>
            <div class="do-block
 
 do-rows">
              <div class="do-row

">
                <div class="do-col-4 do-D-c-34-35-59" id='D-c-34-35-59'>
                  <div class="do-panelcol">
                    <div class="do-block
 
 
 
 
 do-text do-1l34vb">
                      <div class="do-text-1l34vb">
                        <div class="do-element-text do-element-general">
                          <div class="do-element-text-content do-html">
                            <div class="do-html-content">
                              <p style="line-height: 1;"><span style="font-family: SimHei; font-size: 24px; color: rgb(255, 255, 255);"><strong>联系我们</strong></span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="do-block
 
 
 
 
 do-hr do-1l39jf">
                      <div class="do-element-line default ">
                        <div class="do-element-line-content">
                          <div class="do-middle">
                            <div class="do-middle-center">
                              <hr style="border-color:rgb(254, 253, 253);">
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="do-block
 
 
 
 
 do-space do-1l34va">
                      <div class="do-element-space pc" style="padding-top:5.221932114882506%;"></div>
                      <div class="do-element-space phone" style="padding-top:5%;"></div>
                    </div>
                    <div class="do-block
 
 
 
 
 do-text do-1l34v9">
                      <div class="do-text-1l34v9">
                        <div class="do-element-text do-element-general">
                          <div class="do-element-text-content do-html">
                            <div class="do-html-content">
                              <p style="line-height: 2;"><span style="color: rgb(255, 255, 255);"><span style="font-size: 16px;"><span style="font-family: 'Microsoft YaHei',微软雅黑,'MicrosoftJhengHei',华文细黑,STHeiti,MingLiu;">电话：</span></span></span><span style="font-size: 16px; color: rgb(255, 255, 255);">18980777678</span></p>
                              <p style="line-height: 2;"><span style="font-family: &quot;Microsoft YaHei&quot;, 微软雅黑, MicrosoftJhengHei, 华文细黑, STHeiti, MingLiu; font-size: 16px; color: rgb(255, 255, 255);">邮箱：532178620@qq.com</span></p>
                              <p style="line-height: 2;"><span style="font-family: &quot;Microsoft YaHei&quot;, 微软雅黑, MicrosoftJhengHei, 华文细黑, STHeiti, MingLiu; font-size: 16px; color: rgb(255, 255, 255);">地址：</span><span style="font-size: 16px; color: rgb(255, 255, 255);">四川省成都市金牛区金丰路6号7栋1单元16层 &nbsp; &nbsp; &nbsp;11603号</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="do-col-8 do-D-c-34-35-56-57" id='D-c-34-35-56-57'>
                  <div class="do-panelcol">
                    <div class="do-block
 
 do-rows">
                      <div class="do-row

">
                        <div class="do-col-4 do-D-c-34-35-56-57-66" id='D-c-34-35-56-57-66'>
                          <div class="do-panelcol">
                            <div class="do-block
 
 
 
 
 do-text do-1l34v8">
                              <div class="do-text-1l34v8">
                                <div class="do-element-text do-element-general">
                                  <div class="do-element-text-content do-html">
                                    <div class="do-html-content">
                                      <p style="line-height: 1;"><span style="font-family: SimHei; font-size: 24px; color: rgb(255, 255, 255);"><strong>快捷导航</strong></span></p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="do-block
 
 
 
 
 do-hr do-1l39je">
                              <div class="do-element-line default ">
                                <div class="do-element-line-content">
                                  <div class="do-middle">
                                    <div class="do-middle-center">
                                      <hr style="border-color:rgb(253, 253, 253);">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="do-block
 
 
 
 
 do-space do-1l39jg">
                              <div class="do-element-space" style="padding-top:5%;"></div>
                            </div>
                            <div class="do-block
 
 
 
 
 do-list do-1l6ymc">
                              <div class="do-element-media x
 num3 phoneRows2
 ">
                                <div class="do-element-media-content md " id="swiper_1l6ymc" data-rows="3" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1">
                                  <ul class="do-element-media-ul x do-content-grid ">
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 active
 
 pgid-932104
 " data-wow-delay=".0s"><a href="">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>基坑护栏</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932170
 " data-wow-delay=".1s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>锌钢护栏</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932173
 " data-wow-delay=".2s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>护栏网</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-932249
 " data-wow-delay=".3s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>边坡防护网</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-930832
 " data-wow-delay=".4s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>道路护栏</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-933163
 " data-wow-delay=".5s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>产品中心</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-933125
 " data-wow-delay=".6s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>厂区风采</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-931933
 " data-wow-delay=".7s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>工程案例</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-931934
 " data-wow-delay=".8s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>新闻动态</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                    <li class="do-element-media-li
 
 
 
 do-img-animation
 
 
 wow fadeInUp
 
 
 
 
 
 pgid-931935
 " data-wow-delay=".9s"><a href="javascript:;">
                                      <div class="do-element-media-conter clearfix do-caption-noimg ">
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p>联系我们</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      </a></li>
                                  </ul>
                                </div>
                              </div>
                              <style>
.do-1l6ymc .do-middle-center img { width:100%; }.do-1l6ymc .do-title .title { font-size:14px;line-height:1.74em;text-align:center;color:rgb(252, 250, 250); }
</style>
                            </div>
                            <div class="do-block
 
 
 
 
 do-space do-1l34v7">
                              <div class="do-element-space pc" style="padding-top:7.246376811594203%;"></div>
                              <div class="do-element-space phone" style="padding-top:5%;"></div>
                            </div>
                          </div>
                        </div>
                        <div class="do-col-4 do-F-c-87-88-90-96-97-116" id='F-c-87-88-90-96-97-116'>
                          <div class="do-panelcol">
                            <div class="do-block
 
 
 
 
 do-space do-1l39j1">
                              <div class="do-element-space pc" style="padding-top:12.140575079872203%;"></div>
                              <div class="do-element-space phone" style="padding-top:5%;"></div>
                            </div>
                            <div class="do-block
 
 
 
 
 do-list do-1l39j3">
                              <div class="do-element-media x
 num1 phoneRows2
 ">
                                <div class="do-element-media-content " id="swiper_1l39j3" data-rows="1" data-phonerows="2" data-initialslide="0" data-slidespercolumn="1">
                                  <ul class="do-element-media-ul x do-listImgPreview do-content-grid ">
                                    <li class="do-element-media-li
 
 
 
 
 
 
 " data-wow-delay=".0s">
                                      <div class="do-element-media-conter clearfix do-caption ">
                                        <div class="do-media-image-box o-mask">
                                          <div class="do-media-image" style="padding-top:34.946236559139784%;">
                                            <div class="do-media-image-conter sizeimg ">
                                              <div class="do-middle">
                                                <div class="do-middle-center"><img class="scrollLoading" data-src="//v1.cdn-static.cn/2021/6/15/62777_kpxex0mr.jpg?imageView2/2/h/0/q/100" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEElEQVR42gEFAPr/AP///wAI/AL+Sr4t6gAAAABJRU5ErkJggg==" alt="成都锌钢护栏"></div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="do-title do-html-content">
                                          <div class="do-title-body">
                                            <div class="do-title-content do-html-content">
                                              <div class="do-html-content title">
                                                <p style="line-height: 1; text-align: center;"><span style="font-family: &quot;Microsoft YaHei&quot;, 微软雅黑, MicrosoftJhengHei, 华文细黑, STHeiti, MingLiu; font-size: 14px; color: rgb(255, 255, 255);">扫码立即咨询</span></p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                              <style>
.do-1l39j3 .do-middle-center img { width:35%; }
</style>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="do-block
 
 
 
 
 do-space do-1l34v4">
              <div class="do-element-space pc" style="padding-top:1.6666666666666667%;"></div>
              <div class="do-element-space phone" style="padding-top:5%;"></div>
            </div>
            <div class="do-block
 
 
 
 
 do-hr do-1l34v3">
              <div class="do-element-line default " style="padding-top:-1.3333333333333335%;">
                <div class="do-element-line-content">
                  <div class="do-middle">
                    <div class="do-middle-center">
                      <hr style="border-color:rgb(255, 255, 255);">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="do-developers">版权所有© 四川凯聚鑫建设工程有限公司 &nbsp;&nbsp;<a href="javascript:;" target="_blank" rel="nofollow">蜀ICP备2021007191号</a>&nbsp;&nbsp; 
  技术支持：<a href="javascript:;" title="成都智网创联网络科技有限公司" target="_blank" rel="nofollow"><span>成都智网创联网络科技有限公司</span></a></div>
<style>
body .do-developers, .do-developers{color:#666!important;width:100%!important;min-height: 38px!important;}
body .do-developers a, .do-developers a{color:#666!important;display: inline-block!important;}
body .do-developers a:hover, .do-developers a:hover{color:#000!important;}
body .do-developers, .do-developers{display: block!important; border-top:1px solid #ecebeb!important; background:#f3f3f3!important;padding:12px!important;text-align: center!important;font-size: 13px!important;line-height: 100%!important;opacity: 1!important;text-indent:0!important}
body .do-developers i, .do-developers i{font-size:13px!important;vertical-align: middle;position: relative;top:-1px}
body .do-developers *, .do-developers *{opacity: 1!important;text-indent:0!important;display: inline-block!important;}

</style>
</div>
<script src="static/js/js.js" merge="true" crossorigin=""></script>
<script src="static/js/wow.min.js" crossorigin=""></script>
<script src="static/js/head.js" crossorigin=""></script>
<script src="static/js/common.js" crossorigin=""></script>
<script src="static/js/swipers.js" crossorigin=""></script>
<script src="static/js/zhuzi-statistic.js"></script>
</body>
</html>