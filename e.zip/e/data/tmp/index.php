<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>四川锦泰天华交通科技有限公司 - <?=$public_r[sitename]?></title>
<meta name="keywords" content="四川锦泰天华交通科技有限公司">
<meta name="description" content="">
<script src="static/js/jquery-1.11.3.min.js"></script>
<script src="static/js/function.js"></script>
<script src="static/js/gd.js"></script>
<script src="static/js/index.js" type="text/javascript"></script>
<script type="text/javascript" src="static/js/jquery.slidePic.js"></script>
<link rel="shortcut icon" href="/static/image/logo.ico" type="image/x-icon">
<link href="static/css/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/mobile/js/pagemode.js"></script>
</head>
<body>

<div class="top">
  <div class="center"><a href="javascript:;"><img src="/static/picture/logo.jpg" alt="基坑护栏"></a> </div>
</div>
<div class="nav">
  <ul class="center">
    <li class="on"></li>
    <li><a href="/">网站首页</a></li>
    <li><a href="/cpzx/szhl/" rel="nofollow">市政护栏</a></li>
    <li><a href="/cpzx/bpfh/" rel="nofollow">边坡防护</a></li>
    <li><a href="/cpzx/spz/" rel="nofollow">声屏障</a></li>
    <li><a href="/cpzx/wqhl/" rel="nofollow">围墙护栏</a></li>
    <li><a href="/gywm/gcal/" rel="nofollow">工程案例</a></li>
    <li><a href="/gywm/xwdt/" rel="nofollow">新闻动态</a></li>
    <li><a href="/gywm/gsjj/" rel="nofollow">公司简介</a></li>
    <li><a href="/gywm/lxwm/" rel="nofollow">联系我们</a></li>
  </ul>
</div>
<script>
function nav(){
	var navs = $(".nav ul li a");
	for(var i = 0; i < navs.length; i ++){
		runs(i);	
	}
	function runs(i){
		$(".nav ul li a:eq("+i+")").hover(function(){
			$(".nav .on").css({ left:i*10+"%" });
		},function(){
			$(".nav .on").css({ left:"-12.5%" });
		});
	}
	
}
nav();

</script>


<div id="banner" class="Bannerslider">
  <ul class="slides">
    <li>
      <div class="img"><a class="dt" href="javascript:;"><img data-src="static/image/banner2.jpg" alt="基坑护栏"></a> <a class="jj" href="javascript:;"></a> </div>
    </li>
    <li>
      <div class="img"><a class="dt" href="javascript:;"><img data-src="static/image/banner1.jpg" alt="钢筋加工棚"></a></div>
    </li>
    <li>
      <div class="img"><a class="dt" href="javascript:;"><img data-src="static/image/banner3.jpg" alt="电梯门"></a></div>
    </li>
  </ul>
</div>
<script>
	SlidePic({
		id:"banner",
		millisec:10000
	});
</script>
<div class="look">
  <div class="ctcp">
    <div class="cptit"><a href="/cpzx/"><img src="static/picture/cpzs.jpg" alt=""></a></div>
    <div class="cpcon">
      <div style="width: 270px; float: left;">
        <h3 style="height: 50px; background-color: #0171dd;line-height: 50px; color: #fff;font-size: 20px;">产品中心</h3>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq("select classid,classname from {$dbtbpre}enewsclass where bclassid=1 order by myorder,classid ASC",0,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<?php
$classurl=sys_ReturnBqClassname($bqr,9);//取得栏目地址
?>
<h3 style="font-size: 16px; line-height: 40px; height: 40px; background-color: #0171dd; margin-top: 10px;"><a style="color: #fff;" title='<?=$bqr[classname]?>' href="<?=$classurl?>"><?=$bqr[classname]?></a></h3>
<?php
}
}
?>


      </div>
      <div style="width: 900px; float: right;">
        <ul style="width: 100%">

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,12,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
          <li><a href="<?=$bqsr['titleurl']?>"><img width="280" height="210" src="<?=$bqr['titlepic']?>" width="280" height="210" alt="<?=$bqr['title']?>" title="<?=$bqr['title']?>"></a>
            <p><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></p>
          </li>
<?php
}
}
?>

        </ul>
      </div>
    </div>
  </div>
  <div class="other">
    <div class="other_tit">
      <h3><a href="javascript:;">锦泰天华 · 工程案例</a></h3>
    </div>
    <div class="other_conl">
      <ul>
      
        <li><a href="javascript:;"><img width="280" height="210" src="static/picture/20210427114517_0.jpg" width="280" height="210" alt="基坑护栏案例展示" title="基坑护栏案例展示"></a>
          <p><a href="javascript:;">基坑护栏案例展示</a></p>
        </li>
        
        <li><a href="javascript:;"><img width="280" height="210" src="static/picture/20210427114620_1.jpg" width="280" height="210" alt="钢筋加工棚案例展示" title="钢筋加工棚案例展示"></a>
          <p><a href="javascript:;">钢筋加工棚案例展示</a></p>
        </li>
        
        <li><a href="javascript:;"><img width="280" height="210" src="static/picture/20210427114716_1.jpg" width="280" height="210" alt="安全通道案例展示" title="安全通道案例展示"></a>
          <p><a href="javascript:;">安全通道案例展示</a></p>
        </li>
        
        <li><a href="javascript:;"><img width="280" height="210" src="static/picture/20210427114808_0.jpg" width="280" height="210" alt="市政护栏案例展示" title="市政护栏案例展示"></a>
          <p><a href="javascript:;">市政护栏案例展示</a></p>
        </li>
        
      </ul>
    </div>
    <div class="other_conr"> </div>
  </div>
</div>
<div class="lookTitle"> <a href="javascript:;"></a> </div>
<div class="gd" id="gd1">
  <ul>
  
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(41,20,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<li><a href="<?=$bqsr['titleurl']?>"><img width="225" height="170" src="<?=$bqr['titlepic']?>" width="225" height="170"><br><?=$bqr['title']?></a></li>
<?php
}
}
?>



  </ul>
</div>
<script>
  gd({
        box:'gd1',    //盒子id
        rows:1,     //行数
        speed:1000/60,  //速度s
        step:1      //步长px
      });
    </script>
<div style="width: 100%; height: 380px; background:url(static/image/ys_01.jpg) no-repeat center;"></div>
<div style="width: 100%; height: 380px; background:url(static/image/ys_02.jpg) no-repeat center;"></div>
<div style="width: 100%; height: 380px; background:url(static/image/ys_03.jpg) no-repeat center;"></div>
<div style="width: 100%; height: 380px; background:url(static/image/ys_04.jpg) no-repeat center;"></div>
<div style="width: 100%; height: 380px; background:url(static/image/ys_05.jpg) no-repeat center;"></div>
<div class="gsjj">
  <div class="center box">
    <div class="title"><span class="more"><a href="javascript:;">more>></a></span>公司介绍 Company Profile
      <div class="biao">介</div>
    </div>
    <div class="text">
      <div class="left1"> <img src="static/picture/about.jpg" width="478" height="336"> </div>
      <div class="right">
        <div class="gsjj">
          <h1>四川锦泰天华交通科技有限公司</h1>
          <p>&nbsp; &nbsp;&nbsp;四川锦泰天华交通科技有限公司经过数年的稳健经营与拓展，现已成为集设计、开发、制造与销售为一体的实业型企业。</p>
          <p>&nbsp; &nbsp; 我公司生产的产品主要有：基坑护栏、市政护栏、小区护栏网等产品。 随着生产技术的进步，公司生产的各种产品均达到了良好水平，产品远销十几个国家和地区，其质量赢得了客户的好评。</p>
          <p>&nbsp; &nbsp; 我公司员工团结奋进，以严谨的工作作风，依靠同行业中良好的技术设备、优良的产品质量、高效率的服务理念，争得了市场份额，紧跟时代的步伐、务实的品质，使我们确立了自身的赢家地位。选择我们的产品，是你明智之举，欢迎用户光临垂询，以对我们的产品有更进一步的了解，彼此互利，共创辉煌。</p>
          <p>&nbsp; &nbsp; 我公司秉承“以客户为中心，以低价高品质为基础，以更好服务为手段，以客户满意为目标”的经营理念，我们深信：每一个产品就是一条广告，并且我们以更优惠的价格、更好的技术设备、完善的售后服务来赢得用户的信任，我厂竭诚希望与新老客户合作与沟通。</p>
        </div>
      </div>
    </div>
    <div class="shadow"></div>
  </div>
</div>
<div class="team">
  <div class="team_tit box">
    <div class="title"><span class="more"><a href="javascript:;">more>></a></span>公司相册 Company Album
      <div class="biao">相</div>
    </div>
    <div class="iapt">
      <div id="iapl"></div>
      <div id="iapcom">
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/11.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/21.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/31.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/41.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/51.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/61.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/7.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/8.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/9.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
        <dl>
          <a href="javascript:;" title="公司团队">
          <dt><img src="static/picture/10.jpg"></dt>
          </a>
          <dd><a href="javascript:;" title="公司团队">公司团队</a></dd>
        </dl>
      </div>
      <div id="iapr"></div>
    </div>
    <script type="text/javascript">
          var hz = new ScrollPicleft();hz.scrollContId = "iapcom";hz.arrLeftId = "iapl";hz.arrRightId = "iapr";hz.frameWidth = 534;
          hz.pageWidth = 554;hz.speed = 10;hz.space = 10;hz.autoPlay = true;hz.autoPlayTime = 3;hz.initialize();
        </script> 
  </div>
  <div class="news box">
    <div class="title"><span class="more"><a href="/gywm/xwdt/">more>></a></span>新闻动态 News
      <div class="biao">新</div>
    </div>
    <div class="text">
      <div class="news_con">
      <?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(43,1,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
        <dl>
          <dt><a href="<?=$bqsr['titleurl']?>"><img src="<?=$bqr['titlepic']?>" alt="<?=$bqr['title']?>"></a></dt>
          <dd><span class="time"><?=date('Y-m-d',$bqr[newstime])?></span><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
          <p> <?=$bqr['smalltext']?>…</p>
        </dl>
<?php
}
}
?>
        
        
      </div>
      <ul class="newsList">
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(43,6,0,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
        <li><span class="time"><?=date('Y-m-d',$bqr[newstime])?></span><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></li>
<?php
}
}
?>
      </ul>
    </div>
    <div class="shadow"></div>
  </div>
</div>
<div class="friendLink">
  <div class="friendLinkIn"> </div>
</div>

<div class="footer">
<div class="foot_nav">
<div class="foot_nav_nr"> 
<a href="/">网站首页</a>
<a href="/cpzx/szhl/" rel="nofollow">市政护栏</a>
<a href="/cpzx/bpfh/" rel="nofollow">边坡防护</a>
<a href="/cpzx/spz/" rel="nofollow">声屏障</a>
<a href="/cpzx/wqhl/" rel="nofollow">围墙护栏</a>
<a href="/gywm/gcal/" rel="nofollow">工程案例</a>
<a href="/gywm/xwdt/" rel="nofollow">新闻动态</a>
<a href="/gywm/gsjj/" rel="nofollow">公司简介</a>
<a href="/gywm/lxwm/" rel="nofollow">联系我们</a>
 </div>
</div>
<div class="foot_con">
<p>版权所有© <?=$public_r[sitename]?>联系人：华经理<?=$public_r[lxdh]?> </p>
<p>电话：<?=$public_r[fwrx]?> 邮箱：<?=$public_r[kfqq]?>@qq.com 地址：<?=$public_r[gsdz]?> 技术支持：<a href="https://www.shunking.cn" rel="nofollow">舜王科技</a> <a href="https://beian.miit.gov.cn/" rel="nofollow"><?=$public_r[icp]?></a>

</p>
</div>
</div>
<script>
	$(function(){
		$(window).scroll(function(){
			if($(window).scrollTop() > 100){
				$(".ewmBox").fadeIn();
			}else{
				$(".ewmBox").fadeOut();
			}
		});
		
	});
</script> 


</body>
</html>
