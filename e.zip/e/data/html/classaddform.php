<?php
if(!defined('InEmpireCMS'))
{exit();}
?><tr bgcolor='#FFFFFF' height=25><td>测试</td><td>
<input name="cs" type="text" id="cs" value="<?=$ecmsfirstpost==1?"123456":ehtmlspecialchars($addr[cs])?>" size="">
</td></tr>