<?php
//tbs
$schalltb_r=array();

//tbs
?>