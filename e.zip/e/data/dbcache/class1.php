<?php
$class_r[1]=Array('classid'=>1,
'bclassid'=>0,
'classname'=>'产品中心',
'sonclass'=>'|47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64|65|66|67|',
'featherclass'=>'',
'islast'=>0,
'classpath'=>'cpzx',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>1,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>18,
'reorder'=>'newstime DESC',
'listtempid'=>2,
'dtlisttempid'=>2);
$class_r[55]=Array('classid'=>55,
'bclassid'=>1,
'classname'=>'草坪护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/cphl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'草坪护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[56]=Array('classid'=>56,
'bclassid'=>1,
'classname'=>'车间护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/cjhl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'车间护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[57]=Array('classid'=>57,
'bclassid'=>1,
'classname'=>'防撞护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/fzhl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'防撞护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[58]=Array('classid'=>58,
'bclassid'=>1,
'classname'=>'楼梯护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/lthl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'楼梯护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[59]=Array('classid'=>59,
'bclassid'=>1,
'classname'=>'桥梁护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/qlhl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'桥梁护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[60]=Array('classid'=>60,
'bclassid'=>1,
'classname'=>'球场护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/qchl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'球场护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[61]=Array('classid'=>61,
'bclassid'=>1,
'classname'=>'市政护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/szhl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'市政护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[62]=Array('classid'=>62,
'bclassid'=>1,
'classname'=>'双边护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/sbhl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'双边护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[63]=Array('classid'=>63,
'bclassid'=>1,
'classname'=>'围墙护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/wqhl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'围墙护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[64]=Array('classid'=>64,
'bclassid'=>1,
'classname'=>'阳台护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/ythl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'阳台护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[65]=Array('classid'=>65,
'bclassid'=>1,
'classname'=>'建筑网片',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/jzwp',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'建筑网片',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[66]=Array('classid'=>66,
'bclassid'=>1,
'classname'=>'声屏障',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/spz',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'声屏障',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[67]=Array('classid'=>67,
'bclassid'=>1,
'classname'=>'石笼网',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/slw',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'石笼网',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[47]=Array('classid'=>47,
'bclassid'=>1,
'classname'=>'边坡防护',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/bpfh',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'边坡防护',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[48]=Array('classid'=>48,
'bclassid'=>1,
'classname'=>'挡车器',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/dcq',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'挡车器',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[49]=Array('classid'=>49,
'bclassid'=>1,
'classname'=>'电梯井口',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/dtjk',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'电梯井口',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[50]=Array('classid'=>50,
'bclassid'=>1,
'classname'=>'防护棚',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/fhp',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'防护棚',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[51]=Array('classid'=>51,
'bclassid'=>1,
'classname'=>'基坑护栏',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/jkhl',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'基坑护栏',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[52]=Array('classid'=>52,
'bclassid'=>1,
'classname'=>'钢格板',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/ggb',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'钢格板',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[54]=Array('classid'=>54,
'bclassid'=>1,
'classname'=>'铁艺门',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/tym',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'铁艺门',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[53]=Array('classid'=>53,
'bclassid'=>1,
'classname'=>'铝艺门',
'sonclass'=>'',
'featherclass'=>'|1|',
'islast'=>1,
'classpath'=>'cpzx/lym',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'铝艺门',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[41]=Array('classid'=>41,
'bclassid'=>46,
'classname'=>'厂家风采',
'sonclass'=>'',
'featherclass'=>'|46|',
'islast'=>1,
'classpath'=>'gywm/cjfc',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'厂家风采',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[42]=Array('classid'=>42,
'bclassid'=>46,
'classname'=>'工程案例',
'sonclass'=>'',
'featherclass'=>'|46|',
'islast'=>1,
'classpath'=>'gywm/gcal',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'工程案例',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[43]=Array('classid'=>43,
'bclassid'=>46,
'classname'=>'新闻动态',
'sonclass'=>'',
'featherclass'=>'|46|',
'islast'=>1,
'classpath'=>'gywm/xwdt',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'新闻动态',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[44]=Array('classid'=>44,
'bclassid'=>46,
'classname'=>'联系我们',
'sonclass'=>'',
'featherclass'=>'|46|',
'islast'=>1,
'classpath'=>'gywm/lxwm',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>2,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'联系我们',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[45]=Array('classid'=>45,
'bclassid'=>46,
'classname'=>'公司简介',
'sonclass'=>'',
'featherclass'=>'|46|',
'islast'=>1,
'classpath'=>'gywm/gsjj',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>2,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'公司简介',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[46]=Array('classid'=>46,
'bclassid'=>0,
'classname'=>'关于我们',
'sonclass'=>'|41|42|43|44|45|',
'featherclass'=>'',
'islast'=>0,
'classpath'=>'gywm',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>2,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'reorder'=>'newstime DESC',
'listtempid'=>1,
'dtlisttempid'=>1);
?>