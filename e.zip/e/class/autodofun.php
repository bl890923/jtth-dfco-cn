<?php
//This is the Free Version of EmpireCMS.
?>