<?php

define('EmpireCMS_VERSION','7.5');

define('EmpireCMS_CHARVER','UTF-8');

define('EmpireCMS_LASTTIME','201804091030');

define('EmpireCMS_UPDATE','1');

?>